# Company Inc Employee Contract Software Engineer Emily Carter.docx

_Modified: 2025-08-15T06:07:31.320319_

---

Reporting Line

Reports to an Engineering Manager. Works with product owners, designers, QA and SRE.

Key Responsibilities

1) Engineering – Write clean, well-tested code; perform code reviews; maintain documentation.

2) Architecture – Contribute to design and technical decisions; follow agreed patterns.

3) Reliability – Support observability and incident response; fix defects promptly.

4) Security – Follow secure coding and data protection practices.

5) Collaboration – Participate in agile ceremonies; estimate and deliver on commitments.

KPIs

Delivery predictability; defect/escape rate; service reliability; code review throughput; security posture.

Work Pattern

London base with up to two remote days per week.