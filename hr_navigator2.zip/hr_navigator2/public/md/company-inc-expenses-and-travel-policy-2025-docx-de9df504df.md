# Company Inc Expenses and Travel Policy 2025.docx

_Modified: 2025-08-15T06:06:57.017033_

---

Do not split a single purchase into multiple claims to avoid thresholds.

5. Travel

Air: Economy class for shorthaul. Premium Economy may be approved for longhaul or medical/reasonable adjustment. Business class requires Finance Director approval.

Rail: Standard class by default. First class only with written preapproval for compelling business reasons (e.g., client working session).

Taxi/Rideshare: Use when public transport is unavailable/impractical, when carrying heavy equipment, late at night or for safety reasons. Share rides where practical.

Private car: Business mileage reimbursed at HMRC AMAP rates. Keep a mileage log (date, route, purpose, miles).

Carallowance holders: Claim fuel for business journeys using HMRC AFR or submit mileage at the fuelonly rate, as advised by Finance.

Parking/tolls/congestion: Reimbursable when related to business journeys; fines/penalties are not reimbursable.