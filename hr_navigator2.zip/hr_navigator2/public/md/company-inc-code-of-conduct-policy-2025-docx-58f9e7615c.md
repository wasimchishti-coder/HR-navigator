# Company Inc Code of Conduct Policy 2025.docx

_Modified: 2025-08-15T06:07:04.640695_

---

All intellectual property created in the course of employment belongs to the Company.

9. Social Media & Public Communications

Make it clear when views are your own; do not disclose confidential or proprietary information.

Do not post content that could be considered discriminatory, harassing, defamatory or damaging to the Company’s reputation.

Press/media enquiries must be referred to Communications/PR.

10. Health, Safety & Wellbeing

Follow all health and safety requirements on site and when working from home (DSE assessments, risk controls).

Alcohol and drugs: do not be under the influence at work or while on Company duty. Alcohol at work events must be moderate and approved.

Report accidents, nearmisses and hazards promptly to HR/Facilities.

11. Hybrid/Remote Working Conduct

The principal place of work is 80 Strand, London WC2R 0BP. Remote working is permitted for up to two (2) days per week subject to the WFH Policy.