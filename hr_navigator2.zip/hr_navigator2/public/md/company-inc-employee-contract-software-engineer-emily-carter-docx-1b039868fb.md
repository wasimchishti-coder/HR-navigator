# Company Inc Employee Contract Software Engineer Emily Carter.docx

_Modified: 2025-08-21T06:25:02.750157_

---

The Employee shall perform the duties reasonably assigned by the Company consistent with the position of Software Engineer.

Such duties include setting engineering strategy, managing the engineering team, overseeing delivery of projects, ensuring quality and security standards, and controlling relevant budgets.

The Employee shall report to the Chief Executive Officer and shall comply with all reasonable and lawful directions given by the Company.

The Employee shall devote the whole of their time, attention and abilities to the business of the Company during working hours.

4. Place of Work

4.1 Primary Location – The Employee’s principal place of work shall be at the Company’s registered office at 80 Strand, London WC2R 0BP, United Kingdom. This location shall be regarded as the Employee’s base for the purposes of travel, expense claims, and any applicable allowances.