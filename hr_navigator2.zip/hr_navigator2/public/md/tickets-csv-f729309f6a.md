# tickets.csv

_Modified: 2025-08-21T07:04:34.571862_

---

id,subject,status,priority,created_at,updated_at,requester_id,requester_name,requester_email,company_name,num_conversations
8,HR navigator Demo Testing,2,4,2025-08-21T03:02:18Z,2025-08-21T03:29:40Z,158003365613,Sara Thompson,sarathompson@colmeneroio.onmicrosoft.com,colmenero,0
7,Feature Addition,2,4,2025-08-20T03:39:52Z,2025-08-20T11:43:35Z,158003365613,Sara Thompson,sarathompson@colmeneroio.onmicrosoft.com,colmenero,0
6,Support For Testing,2,1,2025-08-20T03:36:33Z,2025-08-20T05:53:53Z,158003365613,Sara Thompson,sarathompson@colmeneroio.onmicrosoft.com,colmenero,0
5,app issue,2,1,2025-08-19T14:00:44Z,2025-08-20T22:14:15Z,158003326731,Chris,chris@gmail.com,,0
4,support request,2,1,2025-08-19T13:34:34Z,2025-08-20T21:39:32Z,158003326514,Umer Rafiq,umermirxa@gmail.com,colmenero,0
3,Test,2,4,2025-08-19T13:28:26Z,2025-08-19T21:42:25Z,158003326514,Umer Rafiq,umermirxa@gmail.com,colmenero,0