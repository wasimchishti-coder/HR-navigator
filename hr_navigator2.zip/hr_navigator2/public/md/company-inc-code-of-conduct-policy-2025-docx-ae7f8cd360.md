# Company Inc Code of Conduct Policy 2025.docx

_Modified: 2025-08-15T06:07:04.640695_

---

Protect customer trust, Company assets and confidential information.

Comply with the law and our internal policies; speak up about concerns.

3. Respect, Inclusion & AntiHarassment

Bullying, harassment and discrimination are not tolerated. This includes unwanted conduct related to protected characteristics under the Equality Act 2010.

Examples of unacceptable behaviour include: offensive jokes or slurs; intimidation; unwanted physical contact; sexual comments; and exclusionary behaviour.

Raise concerns early with your manager or HR. Formal routes are available via the Grievance Policy and Whistleblowing Policy.

4. Professional Conduct

Be courteous and collaborative in all communications (email, chat, video).

Avoid conflicts of interest; disclose any situation that may impair objective judgement.

Do not use position, Company resources or information for personal gain.

5. Conflicts of Interest