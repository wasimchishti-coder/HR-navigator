# employee_records.csv

_Modified: 2025-08-21T06:24:30.188310_

---

Employee ID,Name,Preferred Name,Job Title,Department,Manager,Location,Office,Work Arrangement,Start Date,Seniority Level,Email,Phone,Employment Status,Employment Type,Skills & Training
Emily,Sales Manager,Sales,Sales Director,Boston,Headquarters,Hybrid,2018-05-30,Senior,sarathompson@colmeneroio.onmicrosoft.com,555-4321,On Leave,Part-Time,Sales, Marketing, Customer Relations