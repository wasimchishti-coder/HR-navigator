# Company Inc Corporate Strategy 2025-2028.docx

_Modified: 2025-08-15T06:07:01.807301_

---

16. People, Organisation & Culture

Org (2025): Product & Eng (10-12 squads; architecture guild; platform SRE; security champions). GTM (Brand/Demand/PMM/Field; Enterprise & MM Sales; Alliances; CS/PS). G&A (Finance, HR, Legal, IT, Facilities).

Talent: Career ladders; internal mobility; inclusive hiring; leadership programmes.
Hybrid: Up to 2 WFH days; inoffice rituals (team day, demo day).
Culture: Psychological safety; DEI goals; learning budget; regular retros.

17. Operating Model, Governance & Ways of Working

Cadence: Annual strategy to quarterly OKRs to biweekly business reviews to weekly squad demos.
Decision Rights: DRIs per initiative; RFC process; ADRs.
Governance: Risk & Compliance forum; Data council; Change Advisory Board (platformimpacting changes).
Protocols: Writefirst; async by default; agendadriven meetings; publish notes/decisions.

18. Financial Plan & Investment Thesis