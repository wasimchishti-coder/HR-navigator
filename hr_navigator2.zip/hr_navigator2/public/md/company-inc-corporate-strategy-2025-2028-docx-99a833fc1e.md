# Company Inc Corporate Strategy 2025-2028.docx

_Modified: 2025-08-15T06:07:01.807301_

---

KR2: Timetofirstdeploy ≤ 30 min (P50).

KR3: 99.95% availability; P0 MTTR ≤ 60 min.

KR4: Developer NPS ≥ 55.

Product Objective: Compliancebydesign pipelines 3 policy packs GA; SBOM/provenance for 90% builds; audit pack ≤ 5 min.
GTM Objective: Efficient enterprise motion 3.5× pipeline coverage; win rate 28%; partnersourced ARR 15%.
People Objective: Great teams, great outcomes engagement +6 pts; regretted attrition < 7%; diverse slates 70%.

Appendix B Financial Model Assumptions (Illustrative)

TAM/SAM sizing with bottomup account lists.

Enterprise ACV growth £180k to £260k by FY2028; seat growth 25% YoY.

Compliance pack attach to 35% by FY2027; premium support attach to 30%.

Gross margin lift via cache, autoscaling, reserved capacity.

Hiring ramp aligned to roadmap gates and leading indicators.


Appendix C Role Charters (Excerpts)

Head of Engineering (Director): Engineering strategy, delivery health, budget, security/compliance guardrails; build leaders.