# Company Inc Employee Contract Head of Engineering Gavin Blake.docx

_Modified: 2025-08-14T07:42:42.935955_

---

Annual Bonus – Eligibility for an annual discretionary bonus targeted at 10% of base salary, subject to individual and Company performance metrics.

Executive Training & Development – Access to professional leadership programmes, conferences, and certifications relevant to the role.



General Terms

All benefits are subject to the terms of the relevant schemes, as amended from time to time.

The Company may replace, vary, or withdraw any benefit, provided that any replacement is broadly equivalent in value and scope.

Benefits are non-contractual unless expressly stated otherwise in this Agreement.



8. Annual Leave

The Employee shall be entitled to 25 days annual leave plus UK public holidays.

Holiday must be taken at times approved by the Company and booked in accordance with Company procedures.

The Company may require the Employee to take holiday during periods of closure.

9. Probationary Period