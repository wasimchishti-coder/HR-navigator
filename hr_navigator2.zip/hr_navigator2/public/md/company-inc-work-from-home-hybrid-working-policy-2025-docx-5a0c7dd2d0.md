# Company Inc Work From Home (Hybrid Working) Policy 2025.docx

_Modified: 2025-08-15T06:06:59.264493_

---

Company Inc – Work From Home (Hybrid Working) Policy

Effective date: 1 January 2025
Applies to: All employees, workers, contractors and agency staff of Company Inc in the UK.
Policy owner: HR (People Operations)
Review cycle: Annual or following material legal/organisational change.

1. Purpose & Scope

This Policy sets out the framework for hybrid working at Company Inc. It enables eligible employees to work remotely for part of the week while maintaining collaboration, service levels, information security and employee wellbeing.

This Policy is not a contractual term and may be amended at the Company’s discretion. Nothing herein overrides statutory rights or obligations.

2. Definitions

Hybrid Working: A regular, approved pattern combining onsite and remote work.

Homeworking: Performing duties from the employee’s home or another approved UK address.

Remote Working Day: A day approved in advance for working away from the principal place of work.