# Company Inc Work From Home (Hybrid Working) Policy 2025.docx

_Modified: 2025-08-15T06:06:59.264493_

---

Appendix E – Team WFH Rota Template

E1. Weekly Planner
• Team members • Onsite days • Remote days • Cover/backup arrangements