# HumanResource.pdf

_Modified: 2025-08-12T18:58:19.988148_

---

i)   Medical/sick leave  
ii)  Casual  
iii) Maternity/paternity  
iv) Marriage 
v)  Compassionate  
vi) Compensatory (i.e. in lieu of working on off-days)  
vii) Long leave (i.e. for further campus studies etc.)   
 
 Working Hours: Organization needs to define its working hours per day/per week.  
 
 Overtime policy. 
 
Business Entertainment 
 
Expenses incurred on behalf of the Company, which are in the category of entertainment 
need to be clearly specified for better control environment. Polices may include: 
 
 Business Entertainment Claim Procedure 
 Entertainment at Company offices 
 Entertainment during Business Travel 
 Entertainment of Third Parties 
 Meetings, Away Days & Symposia 
 Staff Business Entertainment 
 Staff Social Get-Together