# Company Inc Expenses and Travel Policy 2025.docx

_Modified: 2025-08-15T06:06:57.017033_

---

Parking/tolls/congestion: Reimbursable when related to business journeys; fines/penalties are not reimbursable.

International travel: Must be preapproved. Ensure visas, insurance and data/security requirements are in place before booking.

6. Accommodation & Meals

Hotels: Book standard rooms in safe, reasonably priced hotels near the business location. Use preferred rates if available.

Caps (incl. taxes/fees): London up to £220/night; Rest of UK up to £140/night. Higher rates require prior approval.

Meals while travelling (not near base office) reimbursable within limits: Breakfast £12, Lunch £15, Dinner £30. Alcohol is not reimbursable unless part of preapproved client entertainment.

Room service, minibars and inroom entertainment are generally not reimbursable unless unavoidable for accessibility/safety; provide justification.

7. Client Entertainment & Gifts

Must have a clear business purpose and prior approval from the Department Head (and Finance for events over £500).