# Company Inc Expenses and Travel Policy 2025.docx

_Modified: 2025-08-15T06:06:57.017033_

---

9. NonReimbursable Items (examples)

Personal travel or addons (sightseeing, leisure, companions’ costs).

Fines and penalties (parking, speeding).

Alcohol (except approved client entertainment).

Class upgrades without approval; excess baggage without business need.

Home utilities and standard commuting costs.

Lost receipts without a completed missingreceipt declaration (Finance may still reject).

10. Receipts, VAT & Deadlines

Submit claims within 10 working days of trip completion and no later than the 5th business day of the following month.

Original itemised receipts (or digital equivalents) are required. For VAT recovery, a valid VAT invoice is necessary where VAT is charged.

Foreign currency expenses are converted using the expense platform’s rate on the transaction date unless otherwise directed by Finance.

False or fraudulent claims may result in disciplinary action up to and including dismissal.

11. Data Protection & Records