# Company Inc Code of Conduct Policy 2025.docx

_Modified: 2025-08-15T06:07:04.640695_

---

I declare the following interests that may give rise to a conflict of interest:

• Outside employment/positions: ___________________________

• Financial interests (suppliers/competitors): ___________________________

• Close personal relationships in reporting lines: ___________________________

• Gifts/hospitality offered/received (details): ___________________________

I will update this declaration if circumstances change.

Signed: ______________________ Date: __________

Appendix B – Gifts & Hospitality Guide

• Cash/cashequivalent gifts (including vouchers): Prohibited.
• Nominal gifts up to £50: may be accepted if infrequent; record in the register.
• Gifts or hospitality over £50: manager preapproval required; record in the register.
• Hospitality should be modest, infrequent and have a clear business purpose.
• Decline anything that appears to create an obligation or influence.

Note: Consider tax/VAT implications and the AntiBribery Policy. When in doubt, ask Finance/HR.