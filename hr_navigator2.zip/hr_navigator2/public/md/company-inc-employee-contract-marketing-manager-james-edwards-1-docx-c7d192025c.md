# Company Inc Employee Contract Marketing Manager James Edwards (1).docx

_Modified: 2025-08-14T07:42:46.288968_

---

8. Annual Leave

The Employee shall be entitled to 25 days annual leave plus UK public holidays.

Holiday must be taken at times approved by the Company and booked in accordance with Company procedures.

The Company may require the Employee to take holiday during periods of closure.

9. Probationary Period

The Employee’s appointment is subject to a probationary period of 6 months during which either party may terminate employment by giving one month’s written notice.

10. Notice Period

Following successful completion of the probationary period, either party may terminate the employment by giving 3 months written notice.

11. Confidentiality

Confidentiality