# Company Inc Expenses and Travel Policy 2025.docx

_Modified: 2025-08-15T06:06:57.017033_

---

Obtain approval in advance where required; keep accurate records/receipts for audit and VAT recovery.

3. Roles & Approvals

Employees submit accurate, timely claims with appropriate receipts.

Line Managers approve claims and verify business purpose and policy compliance.

Finance audits claims, reclaims VAT where possible and may reject or query items.

Approval thresholds: up to £500 – Line Manager; £501–£2,000 – Department Head; over £2,000 – Finance Director/CFO.

4. Payment Methods

Corporate card (where issued) is preferred for travel and lodging; personal cards may be used where a corporate card is not available.

Reimbursement is via payroll or the expense platform after approval. Cash advances require Finance Director approval and must be reconciled within 10 working days of trip end.

Do not split a single purchase into multiple claims to avoid thresholds.

5. Travel