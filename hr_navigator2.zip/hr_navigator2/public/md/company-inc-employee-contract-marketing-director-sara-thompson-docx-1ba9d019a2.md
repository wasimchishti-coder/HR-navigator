# Company Inc Employee Contract Marketing Director Sara Thompson.docx

_Modified: 2025-08-14T07:42:37.720852_

---

• Brand awareness and share of voice.

• Team engagement, retention and agency efficiency.

Work Pattern

Based at 80 Strand, London WC2R 0BP, United Kingdom. Hybrid working pattern with up to two days per week remote working, subject to business needs and information security requirements.