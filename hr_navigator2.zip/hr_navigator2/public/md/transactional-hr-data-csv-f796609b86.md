# transactional_hr_data.csv

_Modified: 2025-08-21T07:04:41.530431_

---

Employee ID,Name,Leave Type,Annual Leave Accrued,Annual Leave Taken,Annual Leave Remaining,Sick Leave Balance,Upcoming Absences,Completed Courses,Payroll Last Date,Payroll Amount,Deductions,Email
E004,Sara Thompson,Annual Leave,15,7,8,6,2025-08-05,Advanced Sales Training,2025-07-30,2700,100,sarathompson@colmeneroio.onmicrosoft.com