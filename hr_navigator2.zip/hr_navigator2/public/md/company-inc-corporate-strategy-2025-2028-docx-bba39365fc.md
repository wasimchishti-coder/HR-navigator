# Company Inc Corporate Strategy 2025-2028.docx

_Modified: 2025-08-15T06:07:01.807301_

---

22. Implementation Plan & Milestones

H2 2025: Policy packs GA; SBOM/provenance; EU residency; portal v1; hire Head of Alliances, Director of Developer Relations, Security TPM.
H1 2026: AI assist beta; incident command center; FinOps guardrails; partner SDK & marketplace v1; SOC 2 readiness; sales playbooks; customer academy.
H2 2026: Financesector blueprints; healthcare pilots; lighthouse public sector win; NRR ≥ 120%; churn < 6%; partners to 20% new ARR.
2027-2028: Multicloud orchestrator; predictive quality; vertical expansions; margin lift via automation; ARR trajectory to £350m; Rule of 40 ≥ 40.

Appendices

Appendix A OKR Tree (Example)

Company Objective (2025 H2): Win trust in regulated markets while accelerating developer speed.

KR1: 20 enterprise wins with compliance automation (>£250k ACV).

KR2: Timetofirstdeploy ≤ 30 min (P50).

KR3: 99.95% availability; P0 MTTR ≤ 60 min.

KR4: Developer NPS ≥ 55.