# Company Inc Code of Conduct Policy 2025.docx

_Modified: 2025-08-15T06:07:04.640695_

---

Note: Consider tax/VAT implications and the AntiBribery Policy. When in doubt, ask Finance/HR.

Appendix C – Employee Acknowledgement

I acknowledge that I have read, understood and agree to comply with the Code of Conduct Policy and related Company policies.

Employee Name: ____________________________ Signature: ____________________________ Date: _____________