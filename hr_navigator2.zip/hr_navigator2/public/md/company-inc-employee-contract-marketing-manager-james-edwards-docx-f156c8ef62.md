# Company Inc Employee Contract Marketing Manager James Edwards.docx

_Modified: 2025-08-15T06:07:27.549539_

---

11. Confidentiality

Confidentiality

11.1 Definition – For the purposes of this Agreement, Confidential Information means any information (whether or not marked as confidential and whether stored in any medium) relating to the business, affairs, products, operations, finances, trade secrets, intellectual property, customers, suppliers, employees, strategies, research, development, software, technical data, and know-how of the Company or any Group Company, which is not in the public domain other than through a breach of this Agreement.

11.2 Non-Disclosure Obligation – The Employee shall not, either during their employment or at any time after termination (howsoever arising), use, copy, or disclose any Confidential Information to any person, company, or other organisation, except:



(a) as required in the proper performance of their duties;

(b) with the Company’s prior written consent; or