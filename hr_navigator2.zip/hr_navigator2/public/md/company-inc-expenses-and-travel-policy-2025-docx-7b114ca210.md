# Company Inc Expenses and Travel Policy 2025.docx

_Modified: 2025-08-15T06:06:57.017033_

---

7. Client Entertainment & Gifts

Must have a clear business purpose and prior approval from the Department Head (and Finance for events over £500).

Keep itemised receipts and a record of attendees and purpose. Alcohol spend should be modest and appropriate.

All activity must comply with the Bribery Act 2010 and the Company’s AntiBribery and Gifts & Hospitality policies.

Gifts are rare; obtain approval in advance. Follow tax/VAT rules and record recipients.

8. Home/Hybrid Working Expenses

Regular home utilities (e.g., broadband, heating) are personal costs and not reimbursable unless expressly approved in writing.

Preapproved ergonomic/DSE equipment may be provided or reimbursed per the WFH Policy and IT guidance.

Travel to the contract base office is a normal commute and not reimbursable.

9. NonReimbursable Items (examples)

Personal travel or addons (sightseeing, leisure, companions’ costs).

Fines and penalties (parking, speeding).