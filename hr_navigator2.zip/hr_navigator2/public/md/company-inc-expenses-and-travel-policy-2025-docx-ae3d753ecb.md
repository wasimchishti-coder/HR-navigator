# Company Inc Expenses and Travel Policy 2025.docx

_Modified: 2025-08-15T06:06:57.017033_

---

Correct cost centre/project code included.

Itemised receipts and VAT invoices attached.

Attendees and purpose recorded for entertainment.

Mileage log completed (date, route, purpose, miles).

Submitted within deadlines.