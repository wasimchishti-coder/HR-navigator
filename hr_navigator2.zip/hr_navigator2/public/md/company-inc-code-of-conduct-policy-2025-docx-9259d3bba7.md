# Company Inc Code of Conduct Policy 2025.docx

_Modified: 2025-08-20T06:40:19.524321_

---

The principal place of work is 80 Strand, London WC2R 0BP. Remote working is permitted for up to two (2) days per week subject to the WFH Policy.

Maintain a safe, secure and professional environment when working remotely; protect confidential information from unauthorised access.

Be available during agreed working hours and attend onsite when requested with reasonable notice.

12. Use of Company Assets

Protect Company equipment, funds and facilities from loss, damage or misuse.

Report loss, theft or damage immediately. Return assets when requested or on leaving the Company.

13. Speaking Up (Whistleblowing)

Raise concerns about wrongdoing (e.g., fraud, bribery, safety risks) via your manager, HR or the Whistleblowing channels.

You are protected under the Public Interest Disclosure Act 1998 when reporting in good faith. Retaliation against reporters is prohibited.

14. Breaches & Consequences