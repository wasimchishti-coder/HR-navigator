# wfh.csv

_Modified: 2025-08-20T06:40:54.204149_

---

email,employee_id,employee_name,department,manager_email,wfh_policy,days_allowed_wfh,approval_required,timezone,last_updated,notes
john.doe@company.com,E001,John Doe,Engineering,lead.eng@company.com,Allowed 2 days/week; manager pre-approval required.,2,Yes,UTC+1,2025-08-01,Core hours 10:00–16:00.
jane.smith@company.com,E002,Jane Smith,Finance,fin.manager@company.com,Allowed 3 days/week; >3 requires CFO approval.,3,Yes,UTC+1,2025-08-02,Quarter-close weeks: WFH limited to 1 day.
sam.brown@company.com,E003,Sam Brown,Support,support.lead@company.com,Allowed 1 day/week.,1,No,UTC,2025-08-03,Ensure on-call coverage.
emily.davis@company.com,E004,Emily Davis,HR,hr.head@company.com,Allowed up to 4 days/week subject to team coverage.,4,Yes,UTC+2,2025-08-01,Onboarding days on-site.
michael.wilson@company.com,E005,Michael Wilson,Sales,sales.dir@company.com,WFH not allowed (client-facing role).,0,No,UTC-5,2025-08-02,Exceptions require VP Sales.