# vacation.csv

_Modified: 2025-08-20T06:40:51.946088_

---

email,employee_id,employee_name,department,manager_email,vacation_days_entitled,vacation_days_taken,vacation_days_left,last_updated,policy_details
john.doe@company.com,E001,John Doe,Engineering,lead.eng@company.com,15,5,10,2025-08-01,Entitled to 15 days/year. Unused days carry over to next year.
jane.smith@company.com,E002,Jane Smith,Finance,fin.manager@company.com,20,8,12,2025-08-02,Entitled to 20 days/year. No carryover.
sam.brown@company.com,E003,Sam Brown,Support,support.lead@company.com,10,5,5,2025-08-03,Entitled to 10 days/year. Carryover up to 1 year.
emily.davis@company.com,E004,Emily Davis,HR,hr.head@company.com,15,7,8,2025-08-01,Entitled to 15 days/year. Must use within next year.
michael.wilson@company.com,E005,Michael Wilson,Sales,sales.dir@company.com,10,10,0,2025-08-02,Entitled to 10 days/year. No carryover.
anna.johnson@company.com,E006,Anna Johnson,Engineering,lead.eng@company.com,15,0,15,2025-08-04,Entitled to 15 days/year. Carryover allowed.