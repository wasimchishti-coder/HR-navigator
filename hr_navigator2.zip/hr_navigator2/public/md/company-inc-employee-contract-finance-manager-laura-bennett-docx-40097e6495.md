# Company Inc Employee Contract Finance Manager Laura Bennett.docx

_Modified: 2025-08-21T07:04:53.512117_

---

‘Place of Work’ means the location stated in clause 4.

Headings are for convenience only and do not affect interpretation. Words in the singular include the plural and vice versa.

2. Appointment and Term

The Company shall employ the Employee as Finance Manager and the Employee accepts such employment on the terms of this Agreement.

The employment shall commence on the Commencement Date and shall continue unless and until terminated in accordance with this Agreement.

The Employee warrants that they are entitled to work in the United Kingdom and that they are not bound by any agreement which would prevent them from fulfilling their duties.

3. Duties and Responsibilities

The Employee shall perform the duties reasonably assigned by the Company consistent with the position of Finance Manager.

Such duties include setting engineering strategy, managing the engineering team, overseeing delivery of projects, ensuring quality and security standards, and controlling relevant budgets.