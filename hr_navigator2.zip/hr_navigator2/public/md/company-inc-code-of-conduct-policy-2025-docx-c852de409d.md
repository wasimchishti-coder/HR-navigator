# Company Inc Code of Conduct Policy 2025.docx

_Modified: 2025-08-15T06:07:04.640695_

---

Do not use position, Company resources or information for personal gain.

5. Conflicts of Interest

A conflict exists where personal interests could improperly influence work decisions.

You must disclose outside employment, close personal relationships in reporting lines, financial interests in suppliers/competitors and gifts/hospitality that could influence decisions.

Complete the Conflict of Interest Declaration (Appendix A) and update it annually or when circumstances change.

6. AntiBribery, Gifts & Hospitality

Bribery is prohibited. Comply with the Bribery Act 2010 and the Company’s AntiBribery Policy.

Cash or cashequivalent gifts (e.g., vouchers) must not be given or accepted.

Reasonable, proportionate hospitality is permitted if it has a clear business purpose and does not create an expectation of undue influence.