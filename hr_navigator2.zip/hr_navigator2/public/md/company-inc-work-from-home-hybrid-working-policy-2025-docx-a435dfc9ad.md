# Company Inc Work From Home (Hybrid Working) Policy 2025.docx

_Modified: 2025-08-15T06:06:59.264493_

---

Employee Name: ____________________________ Signature: ____________________________ Date: _____________

Appendices

Appendix A – Remote Working Request Form

A1. Employee Details
• Name • Job Title • Department • Manager

A2. Proposed Hybrid Pattern
• Requested remote days (e.g., Mon/Tue) • Business rationale • Start date • Review date

A3. Homeworking Address & Setup
• Address • Internet speed/reliability • Workspace description • Equipment required

A4. Approvals
• Manager approval • HR approval • IT approval (security/equipment)

Appendix B – Homeworking SelfAssessment (DSE)

B1. Workstation
• Chair/desk appropriate; adjustable position • Screen at eye level; glare minimised • Keyboard/mouse accessible; wrist support if needed

B2. Environment
• Adequate lighting and ventilation • Trip hazards removed; cables managed • Noise levels acceptable/confidentiality maintained