# Company Inc Expenses and Travel Policy 2025.docx

_Modified: 2025-08-21T07:04:42.952200_

---

Correct cost centre/project code included.

Itemised receipts and VAT invoices attached.

Attendees and purpose recorded for entertainment.

Mileage log completed (date, route, purpose, miles).

Submitted within deadlines.