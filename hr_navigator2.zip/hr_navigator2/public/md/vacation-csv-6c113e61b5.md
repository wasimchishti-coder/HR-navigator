# vacation.csv

_Modified: 2025-08-20T06:40:51.946088_

---

anna.johnson@company.com,E006,Anna Johnson,Engineering,lead.eng@company.com,15,0,15,2025-08-04,Entitled to 15 days/year. Carryover allowed.
chris.lee@company.com,E007,Chris Lee,Marketing,marketing.head@company.com,20,16,4,2025-08-03,Entitled to 20 days/year. Must use within 2 years.
alex.khan@company.com,E008,Alex Khan,Data,ds.manager@company.com,18,6,12,2025-08-03,Entitled to 18 days/year. Carryover allowed.
sara.park@company.com,E009,Sara Park,Product,prod.lead@company.com,12,1,11,2025-08-02,Entitled to 12 days/year. No carryover.
li.wei@company.com,E010,Li Wei,Legal,legal.head@company.com,14,9,5,2025-08-04,Entitled to 14 days/year. Carryover up to 6 months.
sarathompson@colmeneroio.onmicrosoft.com,E010,Li Wei,Legal,legal.head@company.com,14,9,5,2025-08-04,Entitled to 24 days/year. Carryover up to 10 months.