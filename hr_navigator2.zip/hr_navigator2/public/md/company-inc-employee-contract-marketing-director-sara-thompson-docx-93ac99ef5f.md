# Company Inc Employee Contract Marketing Director Sara Thompson.docx

_Modified: 2025-08-21T06:24:48.149113_

---

Company Inc.
Employment Agreement – Marketing Director

Contract Reference: 070691D6
Contract Date: 12 September 2021
Start Date: 20 September 2021

Between: Company Inc, of 80 Strand, London WC2R 0BP, United Kingdom (the 'Company') and Sara Thompson, of 76 Priory Mews, Greenwich, London SE10 8FW (the 'Employee').

This Employment Agreement ('Agreement') sets out the terms and conditions governing the Employee’s employment with the Company. It supersedes and replaces any previous agreements, arrangements, or understandings (whether written or oral) relating to the Employee’s employment.

1. Definitions and Interpretation

In this Agreement, unless the context requires otherwise, the following definitions apply:

‘Agreement’ means this employment contract including any schedules and annexes;

‘Board’ means the Board of Directors of the Company from time to time;

‘Confidential Information’ means all information of a confidential nature relating to the Company or its business;