# Company Inc Employee Contract Software Engineer Emily Carter.docx

_Modified: 2025-08-21T07:05:09.393893_

---

4.2 Flexible Working Arrangement – The Company operates a hybrid working policy under which the Employee is permitted to work remotely from a suitable location within the United Kingdom for up to two (2) days per week.

(a) The Employee’s remote working days are to be agreed in advance with their line manager and may be varied from time to time based on operational requirements.

(b) The Employee shall ensure that their home working environment is safe, secure, and suitable for the performance of their duties, including reliable internet access and compliance with the Company’s data security requirements.

(c) The Company reserves the right to require the Employee to attend the principal place of work on any day ordinarily designated as a remote working day, with reasonable notice, for business meetings, training, or other operational reasons.