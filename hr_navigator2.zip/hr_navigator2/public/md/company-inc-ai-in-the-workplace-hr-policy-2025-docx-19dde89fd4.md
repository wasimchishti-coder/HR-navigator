# Company Inc AI in the Workplace (HR Policy) 2025.docx

_Modified: 2025-08-15T06:07:07.193091_

---

Stop sharing the output; capture the prompt/response and context.

Inform your manager and raise an incident with Security/IT and HR.

Do not delete evidence. Legal/Privacy will assess regulatory notification duties and customer communications.

Contain: rotate credentials, revoke access, purge cached data where supported.

Timelines

Aim to triage within 4 business hours; assess reportability within 72 hours (ICO threshold context dependent).

Safe harbour: Selfreporting in good faith is encouraged and will be taken into account.

13. Roles & Responsibilities

Employees: Use approved tools; protect data; review outputs; log material prompts; escalate when unsure.

Managers: Approve use cases; ensure training; monitor outcomes; reinforce safe practices.

HR: Maintain policy; deliver training; govern Peopleprocess use cases.

Security/IT: Approve vendors; configure controls; monitor; respond to incidents.

Legal/Privacy: Contracts, DPAs/IDTAs/SCCs; DPIAs; regulatory advice.