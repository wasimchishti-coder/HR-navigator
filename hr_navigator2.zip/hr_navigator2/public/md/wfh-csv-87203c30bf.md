# wfh.csv

_Modified: 2025-08-20T06:40:54.204149_

---

anna.johnson@company.com,E006,Anna Johnson,Engineering,lead.eng@company.com,Allowed 2 days/week; flexible per sprint needs.,2,No,UTC+1,2025-08-04,Coordinate with team standups.
chris.lee@company.com,E007,Chris Lee,Marketing,marketing.head@company.com,Allowed 3 days/week.,3,No,UTC+9,2025-08-03,On-site for campaign launch days.
alex.khan@company.com,E008,Alex Khan,Data,ds.manager@company.com,Allowed 4 days/week; ensure data access compliance.,4,Yes,UTC,2025-08-03,Secure VPN required.
sara.park@company.com,E009,Sara Park,Product,prod.lead@company.com,Allowed 2 days/week.,2,No,UTC-3,2025-08-02,Be available for cross-timezone syncs.
li.wei@company.com,E010,Li Wei,Legal,legal.head@company.com,Allowed 1 day/week; legal docs cannot leave office.,1,Yes,UTC+8,2025-08-04,Redlines must be done on-site.
sarathompson@colmeneroio.onmicrosoft.com,E010,Li Wei,Legal,legal.head@company.com,Allowed 1 day/week; legal docs cannot leave office.,1,Yes,UTC+8,2025-08-04,Redlines must be done on-site.