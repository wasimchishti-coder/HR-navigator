# Company Inc Work From Home (Hybrid Working) Policy 2025.docx

_Modified: 2025-08-15T06:06:59.264493_

---

B2. Environment
• Adequate lighting and ventilation • Trip hazards removed; cables managed • Noise levels acceptable/confidentiality maintained

B3. Breaks & Wellbeing
• Regular microbreaks taken • Eyesight tests offered per policy • Workload and hours manageable

Appendix C – Equipment Receipt

C1. Issued Equipment
• Laptop (serial) • Monitor(s) • Docking station • Headset/keyboard/mouse • Other

C2. Employee Confirmation
• I will care for the equipment and return it upon request or termination.
• I will report loss/theft/damage immediately.

Appendix D – Security Incident Reporting

D1. Report Immediately If
• Device is lost, stolen or suspected compromised • Data sent to the wrong recipient • Malware/phishing suspected • Unauthorised access or disclosure

D2. How to Report
• Notify your manager and IT/Security via the incident channel/email
• Record details: what, when, who, data involved
• Follow IT/Security instructions

Appendix E – Team WFH Rota Template