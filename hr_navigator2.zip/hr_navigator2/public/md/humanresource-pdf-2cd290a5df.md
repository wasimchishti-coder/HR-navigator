# HumanResource.pdf

_Modified: 2025-08-12T17:47:09.755877_

---

policies specific to certain categories of employees. General principles would include rules 
such as: 
 
 Age Criteria for Employment: The maximum age of employees is specified – generally in 
Pakistan, the maximum age is 60 years. 
 
 Employment of Relatives : Usually employers not to have relatives working in the same 
department, and especially not in the same reporting lines. Definition of relatives is 
also required to clear ambiguities. 
 
 Non-Discrimination in Employment : Employ ers should specify themselves as equal 
opportunity employer with no discrimination based on gender, religion ethnicity. For