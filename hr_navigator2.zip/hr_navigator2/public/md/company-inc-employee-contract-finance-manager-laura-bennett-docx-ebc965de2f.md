# Company Inc Employee Contract Finance Manager Laura Bennett.docx

_Modified: 2025-08-21T07:04:53.512117_

---

The Employee shall report to the Chief Executive Officer and shall comply with all reasonable and lawful directions given by the Company.

The Employee shall devote the whole of their time, attention and abilities to the business of the Company during working hours.

4. Place of Work

4.1 Primary Location – The Employee’s principal place of work shall be at the Company’s registered office at 80 Strand, London WC2R 0BP, United Kingdom. This location shall be regarded as the Employee’s base for the purposes of travel, expense claims, and any applicable allowances.

4.2 Flexible Working Arrangement – The Company operates a hybrid working policy under which the Employee is permitted to work remotely from a suitable location within the United Kingdom for up to two (2) days per week.

(a) The Employee’s remote working days are to be agreed in advance with their line manager and may be varied from time to time based on operational requirements.