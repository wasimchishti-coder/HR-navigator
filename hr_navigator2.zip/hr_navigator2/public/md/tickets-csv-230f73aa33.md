# tickets.csv

_Modified: 2025-08-21T07:04:34.571862_

---

3,Test,2,4,2025-08-19T13:28:26Z,2025-08-19T21:42:25Z,158003326514,Umer Rafiq,umermirxa@gmail.com,colmenero,0
2,Received a broken TV,2,1,2025-08-19T10:35:13Z,2025-08-20T02:14:27Z,158003325690,Sarah James,sarah.james@advancedmachinery.com,Advanced Machinery,0
1,Email address change,2,2,2025-08-19T10:35:11Z,2025-08-20T09:13:18Z,158003325688,Emily Garcia,emily.garcia@acme.com,Acme Inc,1