# Company Inc Employee Contract Marketing Manager James Edwards (1).docx

_Modified: 2025-08-21T06:24:58.323939_

---

Company Inc.
Employment Agreement – Marketing Manager

Contract Reference: 070691D6
Contract Date: 09 August 2023
Start Date: 11 August 2023

Between: Company Inc, of 80 Strand, London WC2R 0BP, United Kingdom (the 'Company') and James Edwards, of 17 Marlowe Court, Canary Wharf, London E14 8QY (the 'Employee').

This Employment Agreement ('Agreement') sets out the terms and conditions governing the Employee’s employment with the Company. It supersedes and replaces any previous agreements, arrangements, or understandings (whether written or oral) relating to the Employee’s employment.

1. Definitions and Interpretation

In this Agreement, unless the context requires otherwise, the following definitions apply:

‘Agreement’ means this employment contract including any schedules and annexes;

‘Board’ means the Board of Directors of the Company from time to time;

‘Confidential Information’ means all information of a confidential nature relating to the Company or its business;