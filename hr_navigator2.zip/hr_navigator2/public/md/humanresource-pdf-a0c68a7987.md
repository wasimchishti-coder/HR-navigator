# HumanResource.pdf

_Modified: 2025-08-12T18:58:19.988148_

---

HUMAN RESOURCE (HR) POLICIES AND PROCEDURES  
________________________________________________________________________ 
Page 2 of 4 
any specific job, if there is a requirement for certain people not to apply, it should 
also be clarified with reasons. 
 
 Probation and Confirmation (and situations, if any, where probation can be ignored) 
 
Further, policies for specific job categories may include: 
 
 Pre-recruitment Activities for Experienced Hires: Interviews including panel  
interview, tests, assessment centres, etc. 
 
 Recruitment of Graduate Student: Universities/Board of education may be specified, 
in furtherance to the interviews, tests & assessment centres. 
 
 Internships 
 
Compensation and Remuneration 
 
In this area management needs to clearly define the salary and r elated benefits an employee 
should expect from the Company. It should be specific about various benefits employee can