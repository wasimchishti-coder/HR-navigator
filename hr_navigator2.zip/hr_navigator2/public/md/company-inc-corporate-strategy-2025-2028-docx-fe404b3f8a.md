# Company Inc Corporate Strategy 2025-2028.docx

_Modified: 2025-08-21T06:24:38.653268_

---

per developer + per pipeline

Secure+

Regulated

Compliance automation, audit packs, residency, premium support

annual (tiered)

Levers: Seats; pipelines/build minutes; data retention; premium SLAs; compliance packs; marketplace rev share.
Discount Guardrails: Floor pricing; multiyear uplift; givetoget; margin checks.

15. Customer Journey & Success Motions

Stages: Awareness to Evaluation to Pilot to Launch to Adopt to Expand to Advocate.
Onboarding: 306090 success plan; technical enablement; security signoff.

Health Score: Usage (deploys, policy passrate), outcomes (MTTR, cost), support (CSAT), engagement (QBRs).
Renewal/Expansion: Plays by signal (green/amber/red); exec alignment; ROI storytelling; community advocacy.
Support SLAs: P1 1hour; P2 4hour; P3 1business day (premium options for Secure+).

16. People, Organisation & Culture