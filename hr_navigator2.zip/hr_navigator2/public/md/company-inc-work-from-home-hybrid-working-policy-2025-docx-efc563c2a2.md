# Company Inc Work From Home (Hybrid Working) Policy 2025.docx

_Modified: 2025-08-15T06:06:59.264493_

---

10. Working Outside the UK / Data Residency

Working outside the UK is not permitted under this Policy without prior written approval from HR, Legal and the line manager.

Approvals will consider tax, immigration, righttowork, data residency, insurance and export control implications.

Shortterm business travel remains subject to manager approval and Travel & Expenses Policy requirements.

11. Insurance & Liability

Employees are responsible for ensuring that their home insurance permits homeworking and that mortgage/tenancy terms allow it.

The Company maintains employer’s liability insurance for authorised homeworking; this does not extend to family/third parties or unauthorised activities.

PAT (Portable Appliance Testing) and safe use of equipment must be observed per Company guidance.

12. Monitoring, Privacy & Attendance