# gcp_secrets.py
import os
from google.cloud import secretmanager

def get_secret(name: str, version: str = "latest") -> str:
    # Use explicit PROJECT_ID if set; otherwise fall back to the default App Engine project
    project_id = os.getenv("GOOGLE_CLOUD_PROJECT") or os.getenv("GCP_PROJECT") or os.getenv("PROJECT_ID")
    if not project_id:
        raise RuntimeError("No GCP project id found in env (GOOGLE_CLOUD_PROJECT/GCP_PROJECT/PROJECT_ID).")
    client = secretmanager.SecretManagerServiceClient()
    path = client.secret_version_path(project_id, name, version)
    resp = client.access_secret_version(request={"name": path})
    return resp.payload.data.decode("utf-8")
