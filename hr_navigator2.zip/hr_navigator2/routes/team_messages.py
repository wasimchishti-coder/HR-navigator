# routes/team_messages.py
from fastapi import APIRouter, Request, Header, BackgroundTasks
import os, re, json, traceback

from routes.bot_adapter import send_reply, send_typing
from services.conversation_memory import add_message
from services.query_orchestrator import answer_query

router = APIRouter()
MENTION_TAG_RE = re.compile(r"<at>.*?</at>", flags=re.IGNORECASE)

def _strip_teams_mentions(text: str, activity: dict) -> str:
    t = text or ""
    t = MENTION_TAG_RE.sub("", t)
    for ent in activity.get("entities") or []:
        if (ent.get("type") or "").lower() == "mention":
            name = (ent.get("text") or "").strip()
            if name:
                t = t.replace(name, "")
    return t.strip()

def _sender_email(activity: dict) -> str:
    # Replace with your identity extraction if available
    return "sarathompson@colmeneroio.onmicrosoft.com"

def _format_references(references):
    if not references:
        return ""
    # Build Markdown list, avoid duplicates
    seen = set()
    items = []
    for s in references[:6]:
        title = s.get("title") or s.get("filename") or "document"
        url = s.get("url")
        key = (title.lower(), (url or ""))
        if key in seen:
            continue
        seen.add(key)
        if url:
            items.append(f"[{title}]({url})")
        else:
            items.append(title)
    return "\n\n**References:** " + ", ".join(items) if items else ""

def _process_message_async(activity: dict, text: str, email: str):
    try:
        try:
            send_typing(activity)
        except Exception:
            pass

        result = answer_query(text, email=email or None)
        reply_text = result.get("answer") or "Sorry, I couldn’t find anything relevant."

        # Append references once (avoid double "References")
        refs_md = _format_references(result.get("references", []))
        if refs_md:
            reply_text += "\n" + refs_md

        add_message(email, "assistant", reply_text)
        code, body = send_reply(activity, reply_text)
        print(f"[send_reply] status={code} body={(body or '')[:400]}")
    except Exception:
        print("### ERROR in background reply ###")
        print(traceback.format_exc())
        try:
            send_reply(activity, "Sorry, I hit an error. Please try again.")
        except Exception as e2:
            print(f"(error path) failed to send error reply: {e2}")

@router.post("/api/messages")
async def handle_teams_bot_message(
    request: Request,
    background: BackgroundTasks,
    authorization: str = Header(None)
):
    activity = await request.json()
    a_type = (activity.get("type") or "").lower()

    print("\n=== INBOUND /api/messages ===")
    print(f"type={a_type} serviceUrl={activity.get('serviceUrl')} conv={(activity.get('conversation') or {}).get('id')}")
    print(json.dumps(activity, indent=2)[:2000])

    # Debug bot ID alignment
    bot_recipient = (activity.get("recipient") or {}).get("id", "")
    app_id_env = os.getenv("MICROSOFT_APP_ID", "")
    print("BOT recipient.id =", bot_recipient)
    print("ENV MICROSOFT_APP_ID =", app_id_env)

    if a_type == "message":
        raw_text = (activity.get("text") or "").strip()
        text = _strip_teams_mentions(raw_text, activity)
        email = _sender_email(activity)

        add_message(email, "user", text)
        background.add_task(_process_message_async, activity, text, email)
        return {"status": "accepted"}

    elif a_type == "conversationupdate":
        members_added = activity.get("membersAdded") or []
        bot_id = (activity.get("recipient") or {}).get("id")
        someone_joined = any(m.get("id") != bot_id for m in members_added)
        if someone_joined:
            try:
                send_reply(activity, "Hi! I’m HR Navigator. Ask me about policies, vacation, WFH, or ticket status.")
            except Exception as e:
                print(f"welcome failed: {e}")
        return {"status": "ok", "type": a_type}

    return {"status": "ignored", "type": a_type}
