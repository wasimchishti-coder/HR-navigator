# # # routes/chat_handler.py
# # from fastapi import APIRouter, Request, Header, HTTPException, BackgroundTasks
# # from typing import List, Dict, Any, Optional
# # import json, re, traceback, os
# # from pathlib import Path

# # from services.conversation_memory import add_message, get_history
# # from services.tabular_query_service import answer_tabular
# # from services.rag_policy_service import answer_policy_only
# # from services.query_orchestrator import answer_query  # used by Teams route

# # # Freshdesk helpers (unchanged)
# # from services.freshdesk_service import (
# #     fetch_user_tickets,
# #     fetch_ticket_by_id,
# #     summarize_tickets_for_chat,
# # )

# # from langchain_community.chat_models import ChatOpenAI
# # from langchain.schema import SystemMessage, HumanMessage, AIMessage

# # router = APIRouter()

# # # ---------- Helpers: references only (no "Sources") ----------
# # def _dedup_references(srcs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
# #     """
# #     Normalize + deduplicate references. Each ref -> {"title": str, "url": str|None, "page": int|None}
# #     Accepts items shaped like {"source": "...", "filename": "...", "url": "...", "page": ...}
# #     """
# #     seen = set()
# #     out: List[Dict[str, Any]] = []
# #     for s in (srcs or []):
# #         title = (s.get("title")
# #                  or s.get("filename")
# #                  or s.get("source")
# #                  or "").strip()
# #         url = (s.get("url") or "").strip() or None
# #         page = s.get("page")
# #         key = (title.lower(), url or "", str(page) if page is not None else "")
# #         if not title:
# #             continue
# #         if key in seen:
# #             continue
# #         seen.add(key)
# #         out.append({"title": title, "url": url, "page": page})
# #     return out

# # def _format_references_block(refs: List[Dict[str, Any]]) -> str:
# #     """Render a human-friendly References block. No 'Sources:' anywhere."""
# #     if not refs:
# #         return ""
# #     lines = []
# #     for r in refs:
# #         title = r["title"]
# #         page = r.get("page")
# #         url = r.get("url")
# #         suffix = f" (page {page})" if page is not None else ""
# #         if url:
# #             lines.append(f"- [{title}]({url}){suffix}")
# #         else:
# #             lines.append(f"- {title}{suffix}")
# #     return "\n\nReferences:\n" + "\n".join(lines)

# # # ---------- Freshdesk planning via LLM (kept lightweight) ----------
# # _FD_PLANNER_SYS = """You are a planner for Freshdesk actions. Convert the user's request into a STRICT JSON plan.
# # Allowed ops: "list_user_tickets", "get_ticket_by_id", "search_user_tickets", "count_by_status", "summary"
# # Return JSON:
# # {"op":"...","ticket_id":0,"status":"","subject_contains":"","limit":5,"result_type":"scalar|table|summary"}"""

# # def _llm_zero() -> ChatOpenAI:
# #     return ChatOpenAI(temperature=0)

# # def _plan_freshdesk(user_email: str, message: str) -> Dict[str, Any]:
# #     llm = _llm_zero()
# #     sys = SystemMessage(content=_FD_PLANNER_SYS)
# #     usr = HumanMessage(content=f"User: {user_email}\nRequest: {message}")
# #     out = llm.invoke([sys, usr]).content or ""
# #     s, e = out.find("{"), out.rfind("}")
# #     plan = {"op":"summary","ticket_id":0,"status":"","subject_contains":"","limit":5,"result_type":"summary"}
# #     if s != -1 and e != -1:
# #         try:
# #             obj = json.loads(out[s:e+1])
# #             plan.update({k: obj.get(k, plan.get(k)) for k in plan.keys()})
# #         except Exception:
# #             pass
# #     # normalize
# #     try: plan["ticket_id"] = int(plan.get("ticket_id") or 0)
# #     except: plan["ticket_id"] = 0
# #     try: plan["limit"] = max(1, min(50, int(plan.get("limit") or 5)))
# #     except: plan["limit"] = 5
# #     if plan.get("result_type") not in {"scalar","table","summary"}:
# #         plan["result_type"] = "summary"
# #     return plan

# # def _filter_tickets(tix: List[Dict[str,Any]], status: Optional[str], subject_contains: Optional[str], limit: int):
# #     res = tix
# #     if status:
# #         s = status.strip().lower()
# #         res = [t for t in res if str(t.get("status","")).strip().lower()==s]
# #     if subject_contains:
# #         q = subject_contains.strip().lower()
# #         res = [t for t in res if q in str(t.get("subject","")).lower()]
# #     return res[:limit] if limit else res

# # def _exec_freshdesk(user_email: str, plan: Dict[str,Any]) -> Dict[str,Any]:
# #     if not user_email:
# #         raise HTTPException(status_code=400, detail="Email is required for ticket queries")

# #     op = plan.get("op","summary")
# #     limit = int(plan.get("limit") or 5)
# #     status = (plan.get("status") or "").strip()
# #     subject_contains = (plan.get("subject_contains") or "").strip()
# #     ticket_id = int(plan.get("ticket_id") or 0)

# #     if op == "get_ticket_by_id" and ticket_id > 0:
# #         t = fetch_ticket_by_id(ticket_id)
# #         if not t:
# #             return {"answer":"No such ticket.", "natural":f"Ticket #{ticket_id} was not found.", "intent":"ticket", "references":[]}
# #         natural = f"Ticket #{t.get('id')}: {t.get('subject','(no subject)')} [{t.get('status','Unknown')}] last updated {t.get('updated','-')}."
# #         return {"answer": json.dumps(t), "natural": natural, "intent": "ticket", "references": []}

# #     # For list/search/count/summary pull once
# #     tickets = fetch_user_tickets(user_email)
# #     if op == "count_by_status":
# #         cnt = len(_filter_tickets(tickets, status=status, subject_contains=None, limit=99999))
# #         st = status or "all statuses"
# #         return {"answer": str(cnt), "natural": f"You have {cnt} ticket(s) in {st}.", "intent": "ticket", "references": []}

# #     if op == "search_user_tickets":
# #         filtered = _filter_tickets(tickets, status=status, subject_contains=subject_contains, limit=limit)
# #         if not filtered:
# #             return {"answer":"0","natural":"No matching tickets found.","intent":"ticket","references":[]}
# #         lines = "\n".join(f"#{t['id']} – {t.get('subject','(no subject)')} [{t.get('status','Unknown')}] updated: {t.get('updated','-')}" for t in filtered)
# #         return {"answer": str(len(filtered)), "natural": lines, "intent": "ticket", "references": []}

# #     if op == "list_user_tickets":
# #         filtered = _filter_tickets(tickets, status=status, subject_contains=None, limit=limit)
# #         if not filtered:
# #             return {"answer":"0","natural":"No tickets found.","intent":"ticket","references":[]}
# #         lines = "\n".join(f"#{t['id']} – {t.get('subject','(no subject)')} [{t.get('status','Unknown')}] updated: {t.get('updated','-')}" for t in filtered)
# #         return {"answer": str(len(filtered)), "natural": lines, "intent": "ticket", "references": []}

# #     # default → summary
# #     summary = summarize_tickets_for_chat(tickets)
# #     return {"answer": summary, "natural": summary, "intent": "ticket", "references": []}

# # # ---------- /chat ----------
# # @router.post("/")  # body: { email, message, mode }
# # async def handle_user_query(request: Request):
# #     try:
# #         payload = await request.json()
# #     except Exception:
# #         raise HTTPException(status_code=400, detail="Invalid JSON body")

# #     user_email = (payload.get("email") or "").strip().lower()
# #     message = (payload.get("message") or "").strip()
# #     mode = (payload.get("mode") or "policy").strip().lower()   # policy|vacation|wfh|ticket

# #     if not message:
# #         raise HTTPException(status_code=400, detail="Field 'message' is required")

# #     # Store user message
# #     add_message(user_email, "user", message)

# #     # -------------------- explicit routing by mode --------------------
# #     if mode == "ticket":
# #         plan = _plan_freshdesk(user_email, message)
# #         result = _exec_freshdesk(user_email, plan)
# #         reply = result.get("natural") or result.get("answer") or "Okay."
# #         add_message(user_email, "assistant", reply)
# #         # No sources. Only references key (empty for tickets).
# #         return {
# #             "response": result.get("answer",""),
# #             "natural": reply,
# #             "intent": "ticket",
# #             "email_used": user_email,
# #             "references": result.get("references", []),
# #             "plan": plan
# #         }

# #     if mode in {"vacation","wfh"}:
# #         if not user_email:
# #             raise HTTPException(status_code=400, detail="Email is required for this tab")
# #         res = answer_tabular(question=message, user_email=user_email, dataset_hint=mode, allow_all_tables=False)
# #         reply = res.get("natural") or res.get("answer") or "No matching rows."
# #         add_message(user_email, "assistant", reply)
# #         # Build a minimal reference entry from CSV source path, if any
# #         refs = []
# #         src = res.get("source")
# #         if src:
# #             title = Path(str(src)).name
# #             refs = _dedup_references([{"title": title, "url": None}])
# #         return {
# #             "response": res.get("answer",""),
# #             "natural": reply,
# #             "intent": "tabular",
# #             "email_used": user_email,
# #             "references": refs,   # <- only references
# #         }

# #     # DEFAULT: policy/documents only (RAG)
# #     result = answer_policy_only(message, k=4)
# #     reply = result.get("answer","") or ""
# #     add_message(user_email, "assistant", reply)
# #     # Convert any backend sources → references
# #     refs = _dedup_references(result.get("sources", []))
# #     return {
# #         "response": reply,
# #         "natural": reply,
# #         "intent": "general_policy",
# #         "email_used": user_email,
# #         "references": refs,   # <- only references
# #     }

# # # ---------------- Teams Bot (only References added to reply) ----------------
# # from routes.bot_adapter import send_reply, send_typing

# # MENTION_TAG_RE = re.compile(r"<at>.*?</at>", re.IGNORECASE)

# # def _strip_mentions(text: str, activity: dict) -> str:
# #     t = text or ""
# #     t = MENTION_TAG_RE.sub("", t)
# #     for ent in activity.get("entities") or []:
# #         if (ent.get("type") or "").lower() == "mention":
# #             name = (ent.get("text") or "").strip()
# #             if name:
# #                 t = t.replace(name, "")
# #     return t.strip()

# # def _get_email(activity: dict) -> str:
# #     from_obj = activity.get("from") or {}
# #     channel_data = activity.get("channelData") or {}
# #     email = (
# #         (channel_data.get("email") or "")
# #         or (from_obj.get("userPrincipalName") or "")
# #         or (from_obj.get("aadObjectId") or "")
# #         or (from_obj.get("id") or "")
# #     )
# #     return (email or "").lower()

# # @router.post("/api/messages")
# # async def handle_teams_message(request: Request, background: BackgroundTasks, authorization: str = Header(None)):
# #     activity = await request.json()
# #     a_type = (activity.get("type") or "").lower()

# #     if a_type != "message":
# #         return {"status": "ignored", "type": a_type}

# #     raw_text = (activity.get("text") or "").strip()
# #     text = _strip_mentions(raw_text, activity)
# #     email = _get_email(activity)

# #     add_message(email, "user", text)

# #     try:
# #         send_typing(activity)
# #     except Exception:
# #         pass

# #     # Router decides policy/tab/ticket; it returns 'sources' typically.
# #     result = answer_query(text, email=email)

# #     # Prefer natural text if provided
# #     reply_text = result.get("natural") or result.get("answer") or "Okay."

# #     # Build only References (no 'Sources')
# #     refs = _dedup_references(result.get("sources") or result.get("references") or [])
# #     reply_text += _format_references_block(refs)

# #     add_message(email, "assistant", reply_text)
# #     code, body = send_reply(activity, reply_text)

# #     return {"status": "ok", "reply": reply_text, "http": code}
# # # inside routes/chat_handler.py, in handle_user_query(...)
# # from services.freshdesk_service import count_freshdesk_users  # add at top

# # def _is_fd_users_query(txt: str) -> bool:
# #     t = (txt or "").lower()
# #     has_fd = ("freshdesk" in t) or ("fd" in t)
# #     wants_count = ("how many" in t) or ("count" in t) or ("number of" in t)
# #     mentions_users = ("users" in t) or ("contacts" in t) or ("agents" in t)
# #     return has_fd and wants_count and mentions_users

# #     # After parsing message/mode, before other branches:
# #     if _is_fd_users_query(message):
# #         stats = count_freshdesk_users()
# #         reply = (
# #             f"Freshdesk users right now:\n"
# #             f"- Contacts (end users): {stats.get('contacts', 0)}\n"
# #             f"- Agents (support staff): {stats.get('agents', 0)}"
# #         )
# #         add_message(user_email, "assistant", reply)
# #     return {
# #         "response": json.dumps(stats),
# #         "natural": reply,
# #         "intent": "ticket",
# #         "email_used": user_email,
# #         "references": [],  # no policy refs for this
# # }

# # routes/chat_handler.py
# from fastapi import APIRouter, Request, Header, HTTPException, BackgroundTasks
# from typing import List, Dict, Any, Optional
# import json, re, os
# from pathlib import Path

# from services.conversation_memory import add_message
# from services.tabular_query_service import answer_tabular
# from services.rag_policy_service import answer_policy_only

# # Freshdesk API (direct, no LLM)
# from services.freshdesk_service import (
#     fetch_user_tickets,
#     fetch_ticket_by_id,
#     summarize_tickets_for_chat,
#     count_freshdesk_users,    # NEW
# )

# router = APIRouter()

# # ---------- References helpers (for policy only) ----------
# def _dedup_references(srcs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
#     seen = set()
#     out: List[Dict[str, Any]] = []
#     for s in (srcs or []):
#         title = (s.get("title") or s.get("filename") or s.get("source") or "").strip()
#         url = (s.get("url") or "").strip() or None
#         page = s.get("page")
#         key = (title.lower(), url or "", str(page) if page is not None else "")
#         if not title or key in seen:
#             continue
#         seen.add(key)
#         out.append({"title": title, "url": url, "page": page})
#     return out

# def _format_references_block(refs: List[Dict[str, Any]]) -> str:
#     if not refs:
#         return ""
#     lines = []
#     for r in refs:
#         title = r["title"]
#         page = r.get("page")
#         url = r.get("url")
#         suffix = f" (page {page})" if page is not None else ""
#         lines.append(f"- [{title}]({url}){suffix}" if url else f"- {title}{suffix}")
#     return "\n\nReferences:\n" + "\n".join(lines)

# # ---------- NEW: Deterministic Freshdesk intent (no LLM) ----------
# _TICKET_ID_RE = re.compile(r"\b(ticket|case|id)\s*#?\s*(\d+)\b", re.I)

# def _freshdesk_route(msg: str) -> Dict[str, Any] | None:
#     """
#     Return a dict describing the Freshdesk op to run, or None if not Freshdesk.
#     Supported ops (no hallucinations):
#       - get_ticket_by_id {ticket_id}
#       - list_user_tickets {limit?}
#       - count_by_status {status}
#       - users_count (contacts + agents)
#     """
#     if not msg:
#         return None
#     m = msg.lower()

#     # must mention freshdesk / fd / ticket(s)
#     is_fd = ("freshdesk" in m) or (" fd " in f" {m} ") or ("ticket" in m) or ("tickets" in m) or ("agent" in m) or ("contact" in m) or ("users" in m)
#     if not is_fd:
#         return None

#     # 1) users count:
#     if ("how many" in m or "count" in m or "number of" in m) and (("users" in m) or ("contacts" in m) or ("agents" in m)):
#         return {"op": "users_count"}

#     # 2) explicit ticket id:
#     tid = None
#     m_id = _TICKET_ID_RE.search(m)
#     if m_id:
#         tid = int(m_id.group(2))
#         return {"op": "get_ticket_by_id", "ticket_id": tid}

#     # 3) count by status:
#     if "open" in m and "ticket" in m and ("how many" in m or "count" in m):
#         return {"op": "count_by_status", "status": "Open"}
#     if "pending" in m and "ticket" in m and ("how many" in m or "count" in m):
#         return {"op": "count_by_status", "status": "Pending"}
#     if "resolved" in m and "ticket" in m and ("how many" in m or "count" in m):
#         return {"op": "count_by_status", "status": "Resolved"}
#     if "closed" in m and "ticket" in m and ("how many" in m or "count" in m):
#         return {"op": "count_by_status", "status": "Closed"}

#     # 4) list user's tickets (default view)
#     if "ticket" in m or "tickets" in m:
#         # optional limit parsing
#         limit = 5
#         m_lim = re.search(r"\b(show|list)\s+(\d{1,2})\b", m)
#         if m_lim:
#             try:
#                 limit = max(1, min(50, int(m_lim.group(2))))
#             except Exception:
#                 pass


# routes/chat_handler.py
from fastapi import APIRouter, Request, Header, HTTPException, BackgroundTasks
from typing import List, Dict, Any, Optional
import re

from services.conversation_memory import add_message, get_history
from services.query_orchestrator import answer_query  # unified router
import os
router = APIRouter()

# Make sure this matches your deployment
PUBLIC_BASE_URL = "https://hr-navigator-was.uc.r.appspot.com"

# ---------------- References utils (dedupe + render) ----------------
def _dedup_references(refs: Optional[List[Dict[str, Any]]]) -> List[Dict[str, Any]]:
    """
    Normalize + deduplicate references to the shape:
      { "title": str, "url": Optional[str], "page": Optional[int] }
    """
    if not refs:
        return []
    seen = set()
    out: List[Dict[str, Any]] = []
    for r in refs:
        title = (r.get("title") or r.get("filename") or r.get("source") or "").strip()
        if not title:
            continue
        url = (r.get("url") or "").strip() or None
        page = r.get("page")
        # normalize to absolute URL when possible
        if url and not (url.startswith("http://") or url.startswith("https://")):
            url = f"{PUBLIC_BASE_URL.rstrip('/')}/{url.lstrip('/')}"
        key = (title.lower(), url or "", str(page) if page is not None else "")
        if key in seen:
            continue
        seen.add(key)
        out.append({"title": title, "url": url, "page": page})
    return out

def _format_references_block(refs: List[Dict[str, Any]]) -> str:
    """
    Render a human-friendly "References" block (clickable links).
    Do NOT render for small talk; only call this when refs exist.
    """
    if not refs:
        return ""
    lines: List[str] = []
    for r in refs:
        t = r["title"]
        p = r.get("page")
        u = r.get("url")
        suffix = f" (page {p})" if p is not None else ""
        if u:
            lines.append(f"- [{t}]({u}){suffix}")
        else:
            lines.append(f"- {t}{suffix}")
    return "\n\nReferences:\n" + "\n".join(lines)

def _format_reply(reply: str, refs: Optional[List[Dict[str, Any]]]) -> str:
    """
    Clean, concise reply with optional references appended.
    """
    text = (reply or "").strip() or "Okay."
    refs_norm = _dedup_references(refs)
    if refs_norm:
        text += _format_references_block(refs_norm)
    return text

# ---------------- Generic chat endpoint (web/app) ----------------
@router.post("/chat")
async def chat_endpoint(request: Request):
    """
    Body (JSON):
      {
        "message": "<user text>",                # required
        "email": "<user@company.com>",           # optional
        "mode": "policy|vacation|wfh|ticket",    # optional
        "activity": { ... }                      # optional: Teams activity
      }
    """
    try:
        payload = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON body")

    message = (payload.get("message") or "").strip()
    if not message:
        raise HTTPException(status_code=400, detail="Field 'message' is required")

    email = (payload.get("email") or "").strip().lower() or None
    mode = (payload.get("mode") or "").strip().lower() or None
    activity = payload.get("activity") or None

    # Log user turn (minimal)
    add_message(email or "_anon", "user", message)

    # Route via orchestrator
    result = answer_query(message=message, email=email, mode=mode, activity=activity)

    # Compose reply (clean + clickable references)
    reply_text = _format_reply(result.get("natural") or result.get("answer"), result.get("references"))

    # Log assistant turn
    add_message(email or "_anon", "assistant", reply_text)

    return {
        "answer": result.get("answer", ""),
        "natural": result.get("natural", "") or result.get("answer", ""),
        "intent": result.get("intent", ""),
        "references": _dedup_references(result.get("references")),   # links only
        "history": get_history(email or "_anon"),
    }

# ---------------- Teams Bot endpoint ----------------

try:
    from routes.bot_adapter import send_reply, send_typing
except Exception:
    send_reply = None
    send_typing = None

MENTION_TAG_RE = re.compile(r"<at>.*?</at>", re.IGNORECASE)

def _strip_mentions(text: str, activity: dict) -> str:
    t = text or ""
    t = MENTION_TAG_RE.sub("", t)
    for ent in (activity.get("entities") or []):
        if (ent.get("type") or "").lower() == "mention":
            name = (ent.get("text") or "").strip()
            if name:
                t = t.replace(name, "")
    return t.strip()

@router.post("/api/messages")
async def handle_teams_message(request: Request, background: BackgroundTasks, authorization: str = Header(None)):
    """
    Bot Framework entrypoint.
    """
    activity = await request.json()
    a_type = (activity.get("type") or "").lower()

    if a_type != "message":
        return {"status": "ignored", "type": a_type}

    raw_text = (activity.get("text") or "").strip()
    text = _strip_mentions(raw_text, activity)

    # Optional typing signal
    try:
        if send_typing:
            send_typing(activity)
    except Exception:
        pass

    add_message("_teams", "user", text)

    # Orchestrate (Teams id may be used by your adapter to resolve email separately)
    result = answer_query(message=text, email=None, mode=None, activity=activity)

    reply_text = _format_reply(result.get("natural") or result.get("answer"), result.get("references"))

    add_message("_teams", "assistant", reply_text)

    code, body = (200, None)
    try:
        if send_reply:
            code, body = send_reply(activity, reply_text)
    except Exception:
        pass

    return {"status": "ok", "reply": reply_text, "http": code}
