from fastapi import APIRouter, UploadFile, File, Form, HTTPException
from typing import List
from services.rag_policy_service import reindex_all, add_uploaded_file, query_policies

router = APIRouter()

@router.post("/policies/reindex")
def policies_reindex():
    """Rebuild FAISS index from all documents in the directory."""
    count = reindex_all()
    return {"status": "ok", "chunks_indexed": count}

@router.post("/policies/upload")
async def policies_upload(files: List[UploadFile] = File(...)):
    """Upload one or more documents for processing."""
    total_chunks = 0
    for f in files:
        data = await f.read()
        added = add_uploaded_file(f.filename, data)
        total_chunks += added
    return {"status": "ok", "chunks_added": total_chunks, "files": [f.filename for f in files]}

@router.post("/policies/query")
def policies_query(question: str = Form(...), k: int = Form(4)):
    """Query policies for a specific question."""
    if not question.strip():
        raise HTTPException(status_code=400, detail="question is required")
    result = query_policies(question, k=k)
    return result
