
# bot_adapter.py
import os
import time
import json
import requests
from urllib.parse import urlparse

APP_ID = os.getenv("MICROSOFT_APP_ID", "")
APP_PASSWORD = os.getenv("MICROSOFT_APP_PASSWORD", "")
# Keep tenant default to 'botframework.com' unless you KNOW you need another
TENANT = (os.getenv("MICROSOFT_TENANT_ID") or "botframework.com").strip()

_session = requests.Session()
# cache token PER SCOPE (important when clouds differ)
_token_cache = {}  # {scope: {"access_token": str, "exp": epoch_float}}

def _token_url() -> str:
    return f"https://login.microsoftonline.com/{TENANT}/oauth2/v2.0/token"

def _scope_for_service_url(service_url: str) -> str:
    """
    Pick the correct OAuth scope by cloud.
    """
    host = (urlparse(service_url).hostname or "").lower()
    # US Gov clouds
    if host.endswith(".botframework.us"):
        return "https://api.botframework.us/.default"
    # China cloud
    if host.endswith(".azure.cn") or "botframework.azure.cn" in host:
        return "https://api.botframework.azure.cn/.default"
    # Public cloud (Teams)
    return "https://api.botframework.com/.default"

def _get_app_token(scope: str) -> str:
    now = time.time()
    cached = _token_cache.get(scope)
    if cached and cached["access_token"] and cached["exp"] - now > 60:
        return cached["access_token"]

    if not APP_ID or not APP_PASSWORD:
        raise RuntimeError("MICROSOFT_APP_ID / MICROSOFT_APP_PASSWORD missing")

    data = {
        "grant_type": "client_credentials",
        "client_id": APP_ID,
        "client_secret": APP_PASSWORD,
        "scope": scope,
    }
    r = _session.post(_token_url(), data=data, timeout=15)
    try:
        r.raise_for_status()
    except requests.HTTPError as e:
        raise RuntimeError(f"Token fetch failed ({r.status_code}): {r.text}") from e

    j = r.json()
    _token_cache[scope] = {
        "access_token": j["access_token"],
        "exp": now + int(j.get("expires_in", 3600)),
    }
    return _token_cache[scope]["access_token"]

def _post_activity(activity: dict, payload: dict) -> requests.Response:
    """Post an activity (message/typing) back into this conversation."""
    service_url = (activity.get("serviceUrl") or "").rstrip("/")
    conversation_id = ((activity.get("conversation") or {}).get("id") or "").strip()
    if not service_url or not conversation_id:
        raise RuntimeError(f"Missing serviceUrl/conversation in activity: {json.dumps(activity)[:400]}")

    scope = _scope_for_service_url(service_url)
    token = _get_app_token(scope)

    bot_identity = activity.get("recipient") or {}
    user_identity = activity.get("from") or {}

    body = {
        **payload,
        "from": bot_identity,       # REQUIRED
        "recipient": user_identity, # good practice
        # You can also include channelData/tenant here when starting NEW conversations.
    }

    reply_to = (activity.get("id") or "").strip()
    if reply_to and body.get("type") == "message":
        body["replyToId"] = reply_to

    url = f"{service_url}/v3/conversations/{conversation_id}/activities"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }
    resp = _session.post(url, headers=headers, json=body, timeout=15)

    # Auto-refresh on 401 once
    if resp.status_code == 401:
        # drop this scope's cache and retry
        _token_cache.pop(scope, None)
        token = _get_app_token(scope)
        headers["Authorization"] = f"Bearer {token}"
        resp = _session.post(url, headers=headers, json=body, timeout=15)

    return resp

def send_typing(activity: dict) -> None:
    try:
        _post_activity(activity, {"type": "typing"})
    except Exception:
        pass

# def send_reply(activity: dict, text: str) -> tuple[int, str]:
#     service_url = activity["serviceUrl"].rstrip("/")
#     conv_id = activity["conversation"]["id"]
#     url = f"{service_url}/v3/conversations/{conv_id}/activities"

#     # Teams tenant id (required for channel replies/proactive)
#     tenant_id = ((activity.get("channelData") or {}).get("tenant") or {}).get("id")

#     token = _get_app_token(_scope_for_service_url(service_url))
#     headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

#     body = {
#         "type": "message",
#         "text": text,
#         "replyToId": activity.get("id"),  # thread-safe in channels
#     }
#     if tenant_id:
#         body["channelData"] = {"tenant": {"id": tenant_id}}

#     r = _session.post(url, headers=headers, json=body, timeout=15)
#     # Optional: single retry on 401
#     if r.status_code == 401:
#         _token_cache.pop(_scope_for_service_url(service_url), None)
#         token = _get_app_token(_scope_for_service_url(service_url))
#         headers["Authorization"] = f"Bearer {token}"
#         r = _session.post(url, headers=headers, json=body, timeout=15)
#     return r.status_code, r.text
# bot_adapter.py  (only the send_reply function changed)

def send_reply(activity: dict, text: str) -> tuple[int, str]:
    service_url = activity["serviceUrl"].rstrip("/")
    conv_id = activity["conversation"]["id"]
    url = f"{service_url}/v3/conversations/{conv_id}/activities"

    # Teams tenant id (helps in channels)
    tenant_id = ((activity.get("channelData") or {}).get("tenant") or {}).get("id")

    token = _get_app_token(_scope_for_service_url(service_url))
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

    body = {
        "type": "message",
        "text": text,
        "textFormat": "markdown",           # 👈 tell Teams to render Markdown
        "replyToId": activity.get("id"),
    }
    if tenant_id:
        body["channelData"] = {"tenant": {"id": tenant_id}}

    r = _session.post(url, headers=headers, json=body, timeout=15)

    if r.status_code == 401:
        _token_cache.pop(_scope_for_service_url(service_url), None)
        token = _get_app_token(_scope_for_service_url(service_url))
        headers["Authorization"] = f"Bearer {token}"
        r = _session.post(url, headers=headers, json=body, timeout=15)
    return r.status_code, r.text
