# storage_utils.py
from google.cloud import storage

def upload_text(bucket_name: str, blob_path: str, text: str, content_type: str = "text/markdown") -> str:
    client = storage.Client()
    bucket = client.bucket(bucket_name)
    blob = bucket.blob(blob_path)
    blob.upload_from_string(text, content_type=content_type)
    blob.make_public()  # optional; remove if you’ll sign URLs instead
    return blob.public_url
