# config.py
import os
from dotenv import load_dotenv

load_dotenv()  # loads .env into process env

def _env(name: str, default: str | None = None, required: bool = False) -> str | None:
    val = os.getenv(name, default)
    if required and (val is None or val == ""):
        raise RuntimeError(f"Missing required environment variable: {name}")
    return val

# --- OpenAI ---
OPENAI_API_KEY = _env("OPENAI_API_KEY", required=True)

# --- Freshdesk ---
FRESHDESK_DOMAIN = _env("FRESHDESK_DOMAIN")          # e.g. chris1303es.freshdesk.com
FRESHDESK_API_KEY = _env("FRESHDESK_API_KEY")
FRESHDESK_TIMEOUT_SECONDS = int(os.getenv("FRESHDESK_TIMEOUT_SECONDS", "10"))

# --- Microsoft Bot / Teams ---
MICROSOFT_APP_ID = _env("MICROSOFT_APP_ID", required=True)
MICROSOFT_APP_PASSWORD = _env("MICROSOFT_APP_PASSWORD", required=True)
MICROSOFT_TENANT_ID = _env("MICROSOFT_TENANT_ID", default="common")  # or your tenant GUID

# Bot Framework constants
BOT_TOKEN_TENANT = "botframework.com"
BOT_OAUTH_TOKEN_URL = f"https://login.microsoftonline.com/{MICROSOFT_TENANT_ID}/oauth2/v2.0/token"

BOT_SCOPE = "https://api.botframework.com/.default"

# Optional: ngrok base used by your local test client UI
NGROK_BASE = _env("NGROK_BASE")  # e.g. https://xxxx.ngrok-free.app
