# main.py
import os
from pathlib import Path
from urllib.parse import unquote
import mimetypes
import markdown  # pip install markdown

from fastapi import FastAPI, Request, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import (
    FileResponse, HTMLResponse, PlainTextResponse, Response, RedirectResponse
)
from fastapi.staticfiles import StaticFiles

from routes.chat_handler import router as chat_router
from routes.policies import router as policies_router
from routes.team_messages import router as teams_router
from gcp_secrets import get_secret

BASE_DIR = Path(__file__).resolve().parent
PUBLIC_DIR = BASE_DIR / "public"
MD_DIR = PUBLIC_DIR / "md"
DOCS_DIR = BASE_DIR / "data" / "hr_policies"

app = FastAPI(title="HR Navigator Demo")

# ---------------- CORS ----------------
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # tighten in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---------------- Ensure directories ----------------
PUBLIC_DIR.mkdir(parents=True, exist_ok=True)
MD_DIR.mkdir(parents=True, exist_ok=True)
DOCS_DIR.mkdir(parents=True, exist_ok=True)

# ---------------- Helpers ----------------
def _safe_within(base: Path, target: Path) -> Path:
    base_res = base.resolve()
    tgt_res = target.resolve()
    if not str(tgt_res).startswith(str(base_res)):
        raise HTTPException(status_code=403, detail="Access denied")
    return tgt_res

def _as_attachment(path: Path, download_name: str | None = None) -> FileResponse:
    mt, _ = mimetypes.guess_type(str(path))
    return FileResponse(
        path,
        media_type=mt or "application/octet-stream",
        filename=download_name or path.name,  # sets Content-Disposition: attachment
    )

# ---------------- Primary Markdown route (NO /public prefix) ----------------
# IMPORTANT: define BEFORE the /public StaticFiles mount so it isn’t shadowed.
@app.get("/md/{filename}")
async def serve_md(filename: str, download: str | None = Query(default=None)):
    """
    Preview markdown as HTML or force download with ?download=1.
    Files are read from PUBLIC_DIR/md.
    """
    fpath = _safe_within(MD_DIR, MD_DIR / filename)
    if not fpath.exists() or not fpath.is_file():
        return PlainTextResponse("File not found", status_code=404)

    if str(download).lower() in {"1", "true", "yes"}:
        return _as_attachment(fpath, download_name=filename)

    raw_md = fpath.read_text(encoding="utf-8", errors="ignore").strip()
    if not raw_md:
        return _as_attachment(fpath, download_name=filename)

    html_body = markdown.markdown(raw_md)
    html_content = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <title>{filename}</title>
        <style>
            body {{ font-family: Arial, sans-serif; margin: 40px; line-height: 1.6; }}
            h1,h2,h3 {{ color: #2c3e50; }}
            pre, code {{ background: #f4f4f4; padding: 6px 10px; border-radius: 4px; }}
            ul, ol {{ margin-left: 20px; }}
            .bar {{ margin-bottom: 18px; padding-bottom: 12px; border-bottom: 1px solid #eee; }}
            .btn {{ display:inline-block; padding:8px 12px; text-decoration:none; border:1px solid #ccc; border-radius:4px; }}
        </style>
    </head>
    <body>
        <div class="bar">
            <a class="btn" href="?download=1">Download this preview</a>
        </div>
        <h2>{filename}</h2>
        {html_body}
    </body>
    </html>
    """
    return HTMLResponse(content=html_content)

# ------------- Legacy redirect so old /public/md/... links still work ----------
@app.get("/public/md/{filename}")
async def legacy_public_md(filename: str, request: Request):
    # Preserve ?download=1 if present
    q = request.url.query
    target = f"/md/{filename}"
    if q:
        target = f"{target}?{q}"
    return RedirectResponse(target, status_code=307)

# ---------------- Optional: explicit download endpoints ----------------
@app.get("/download/md")
async def download_md(file: str = Query(..., description="Filename under /public/md")):
    fpath = _safe_within(MD_DIR, MD_DIR / unquote(file))
    if not fpath.exists() or not fpath.is_file():
        raise HTTPException(status_code=404, detail="File not found")
    return _as_attachment(fpath, download_name=Path(file).name)

@app.get("/download/original")
async def download_original(file: str = Query(..., description="File under /data/hr_policies")):
    fpath = _safe_within(DOCS_DIR, DOCS_DIR / unquote(file))
    if not fpath.exists() or not fpath.is_file():
        raise HTTPException(status_code=404, detail="File not found")
    return _as_attachment(fpath, download_name=Path(file).name)

# ---------------- Static after dynamic routes (so it doesn't shadow /md) ------
app.mount("/public", StaticFiles(directory=str(PUBLIC_DIR), html=True), name="public")

# ---------------- Routers ----------------
app.include_router(chat_router, prefix="/chat", tags=["HR Bot (manual)"])
app.include_router(teams_router, tags=["Teams"])
app.include_router(policies_router, tags=["Policies"])

# ---------------- Health/Test ----------------
@app.get("/")
def health():
    return {"status": "ok", "service": "hr-navigator"}

@app.get("/test-client")
def get_test_client():
    html_path = Path("templates") / "test_client.html"
    return FileResponse(html_path)

# ---------------- Ngrok header (cosmetic) ----------------
@app.middleware("http")
async def add_ngrok_skip_header(request: Request, call_next):
    resp: Response = await call_next(request)
    resp.headers["ngrok-skip-browser-warning"] = "true"
    return resp
