# services/query_orchestrator.py
import json
from typing import Optional, Dict, Any, List

from services.tabular_query_service import answer_tabular
from services.rag_policy_service import answer_policy_only
from services.conversation_memory import get_history, add_message

from langchain_openai import ChatOpenAI
from langchain.schema import SystemMessage, HumanMessage, AIMessage

# IMPORTANT: public base for clickable links (used for tabular links only)
PUBLIC_BASE_URL = "https://hr-navigator-was.uc.r.appspot.com".rstrip("/")

# ---------------- LLM System Prompt (general combine, emotion-aware) ----------------
_COMBINE_SYS = """
You are a Human Resources (HR) assistant for a company.

Tone & Style:
- Friendly, warm, and empathetic; concise and clear.
- Sound like a real colleague (never mention AI/bot). Avoid boilerplate.
- Vary openings so replies don’t feel repetitive.

Emotion Awareness:
- If the user’s emotion is noticeable (frustrated, stressed, worried, confused, sad, or happy),
  open with one brief, genuine acknowledgement (one line max), then move to solutions.
- Don’t over-apologize.

Conversation & Context:
- Maintain flow using the last 12 messages (treat follow-ups as part of the same thread).
- If it’s small talk (hi/hello/thanks), keep it warm and very brief (no references).

Answering Rules:
- Answer the user’s exact question first; add up to 3 short bullets if helpful.
- Prioritize personal HR data (tabular) for employee-specific queries (leave balance, payroll, WFH usage).
- Use policy content for policy questions. If info is missing, say so briefly and suggest the next step.
- Do not hallucinate; stay grounded in the provided tabular/policy context.

Formatting:
- Start with the direct answer (after any brief empathy line, if relevant).
- Keep it scannable.
- Do NOT include your own 'References:' block—client may append references.
"""

def _is_small_talk(text: str) -> bool:
    if not text:
        return False
    t = text.strip().lower()
    small = {
        "hi", "hello", "hey", "how are you", "thanks", "thank you", "who are you?",
        "good morning", "good evening", "good afternoon"
    }
    return any(phrase == t or phrase in t for phrase in small)

def _combine_with_llm(
    query: str,
    tabular: Dict[str, Any],
    policy: Dict[str, Any],
    user_history: List[dict],
) -> str:
    llm = ChatOpenAI(temperature=0.3)

    msgs: List[Any] = [SystemMessage(content=_COMBINE_SYS)]

    # Feed last 12 messages as conversational context (user + assistant)
    for m in user_history[-12:]:
        role = (m.get("role") or "").lower()
        content = (m.get("content") or "").strip()
        if not content:
            continue
        if role == "user":
            msgs.append(HumanMessage(content=content))
        else:
            msgs.append(AIMessage(content=content))

    # Current query payload (HR data + policy)
    payload = {
        "query": query,
        "tabular": tabular or {},
        "policy": policy or {},
    }
    msgs.append(HumanMessage(content=json.dumps(payload, ensure_ascii=False, indent=2)))

    out = llm.invoke(msgs).content or ""
    return out.strip()

def _tabular_across_known_tables(question: str, email: Optional[str]) -> Dict[str, Any]:
    """
    Try employee_records and transactional_hr_data. Return best non-empty result.
    """
    stems = ["employee_records", "transactional_hr_data"]
    for stem in stems:
        res = answer_tabular(question=question, user_email=email, dataset_hint=stem, allow_all_tables=False)
        ans = (res or {}).get("answer")
        if res and res.get("handled") and ans and str(ans).strip().upper() != "N/A":
            return res
    return {"handled": False, "answer": "", "natural": "", "source": None}

def _collect_references(policy_res: Dict[str, Any], tabular_res: Dict[str, Any], is_small: bool) -> List[Dict[str, str]]:
    """
    Create a unique list of clickable references. Skip for small talk.
    """
    if is_small:
        return []

    refs: List[Dict[str, str]] = []
    seen = set()

    # Policy/RAG sources (expected {title,url} list)
    for s in (policy_res.get("sources") or []):
        title = (s.get("title") or s.get("filename") or "reference").strip()
        url = (s.get("url") or "").strip()
        key = (title.lower(), url)
        if key in seen:
            continue
        seen.add(key)
        item = {"title": title}
        if url:
            item["url"] = url
        refs.append(item)

    # Tabular source (e.g., "tables/employee_records.csv")
    t_src = (tabular_res.get("source") or "").strip()
    if t_src:
        # If not absolute, prefix with PUBLIC_BASE_URL
        if not (t_src.startswith("http://") or t_src.startswith("https://")):
            t_url = f"{PUBLIC_BASE_URL}/{t_src.lstrip('/')}"
        else:
            t_url = t_src
        key = (t_src.lower(), t_url)
        if key not in seen:
            seen.add(key)
            refs.append({"title": t_src.split("/")[-1], "url": t_url})

    return refs

# ---------------- Public API ----------------
def answer_query(
    message: str,
    email: Optional[str] = None,
    mode: Optional[str] = None,
    activity: Optional[dict] = None,
) -> Dict[str, Any]:
    """
    Unified HR query handler (NO special ticket logic)
    - Personal data (tabular): employee_records.csv / transactional_hr_data.csv
    - HR policy RAG (embeddings only)
    - Conversation context (last 12 messages)
    - Clickable references
    - Logs all messages
    """
    query = (message or "").strip()
    user_id = (email or "_anon").strip().lower()
    history = get_history(user_id)

    # ----- Standard path: HR (tabular + policy RAG) -----
    tabular_res = _tabular_across_known_tables(query, email)
    policy_res = answer_policy_only(query, k=4)

    reply = _combine_with_llm(
        query=query,
        tabular=tabular_res,
        policy=policy_res,
        user_history=history,
    )

    is_small = _is_small_talk(query)
    references = _collect_references(policy_res, tabular_res, is_small)

    # Log both sides
    add_message(user_id, "user", query)
    add_message(user_id, "assistant", reply)

    return {
        "answer": reply,
        "natural": reply,
        "intent": "combined",
        "references": references,
        "history": get_history(user_id),
    }
