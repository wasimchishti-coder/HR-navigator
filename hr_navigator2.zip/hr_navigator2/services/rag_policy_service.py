import os
import json
import pickle
import re
import hashlib
from urllib.parse import quote
from pathlib import Path
from datetime import datetime
from typing import Optional, List, Dict, Any
from dotenv import load_dotenv
import pandas as pd
from storage_utils import upload_text
from langchain_openai import OpenAIEmbeddings, ChatOpenAI
from langchain_community.vectorstores import FAISS
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.chains import RetrievalQA
from langchain.schema import SystemMessage, HumanMessage
from langchain.prompts import ChatPromptTemplate

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent.parent
DOCS_DIR = BASE_DIR / "data" / "hr_policies"
EMBED_DIR = BASE_DIR / "embeddings"
INDEX_DIR = EMBED_DIR / "faiss_index"
VSTORE_PKL = EMBED_DIR / "vectorstore.pkl"  # legacy
TABLES_DIR = BASE_DIR / "data" / "tables"

PUBLIC_DIR = BASE_DIR / "public"
MD_DIR = PUBLIC_DIR / "md"
PUBLIC_BASE_URL = os.getenv("PUBLIC_BASE_URL", "/public").rstrip("/")

SPLITTER = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=150, length_function=len)

GCP_BUCKET_PUBLIC = os.getenv("GCP_BUCKET_PUBLIC", "")

def _ensure_dirs() -> None:
    DOCS_DIR.mkdir(parents=True, exist_ok=True)
    EMBED_DIR.mkdir(parents=True, exist_ok=True)
    INDEX_DIR.mkdir(parents=True, exist_ok=True)
    TABLES_DIR.mkdir(parents=True, exist_ok=True)
    PUBLIC_DIR.mkdir(parents=True, exist_ok=True)
    MD_DIR.mkdir(parents=True, exist_ok=True)

# ---------------- Emotion-aware, grounded policy prompt ----------------
COLEM_NERO_POLICY_SYSTEM = """
You are an HR assistant for a company.

Tone & Style:
- Friendly, warm, and empathetic; concise and clear.
- Sound like a real colleague (never mention AI/bot). Avoid boilerplate.

Emotion Awareness:
- If the user’s emotion is noticeable (frustrated, stressed, worried, confused, sad, or happy),
  begin with one brief, genuine acknowledgement (one line max), then move to solutions.
- Don’t over-apologize.

Grounding:
- Use ONLY the provided context to answer policy questions. If it’s not in context, say you don’t have enough info.
- Be precise and avoid speculation. If policy has conditions/exceptions, state them plainly.

Clarity:
- Answer the question first; add up to 3 short bullets if helpful.
- Do NOT include your own “References” section or generic filler (e.g., “feel free to ask more”).
"""

POLICY_CHAT_PROMPT = ChatPromptTemplate.from_messages([
    ("system", COLEM_NERO_POLICY_SYSTEM),
    ("human", "Use ONLY the context to answer. If it’s not in context, say you don’t have enough info.\n\nContext:\n{context}\n\nQuestion: {question}")
])

# ---------------- Small talk handling (no references for chit-chat) ----------------
_SMALL_TALK_PHRASES = {
    "hi","hello","hey","hiya","how are you","how are you doing","thanks","thank you",
    "who are you?","good morning","good evening","good afternoon","ok","okay","k",
    "cool","great","awesome","got it","i see","noted","understood","ah","ahh","ahhh","ahhh i see"
}

def classify_small_talk(text: str) -> (bool, str):
    t = (text or "").strip().lower()
    if not t:
        return False, ""
    if any(p in t for p in _SMALL_TALK_PHRASES) and len(t) <= 30:
        # brief, warm acknowledgement; no references
        return True, "Got it — I’m here if you need anything else about HR."
    return False, ""

# ---------------- Retriever chain ----------------
def _build_policy_chain(retriever):
    llm = ChatOpenAI(temperature=0)
    return RetrievalQA.from_chain_type(
        llm=llm,
        retriever=retriever,
        chain_type="stuff",
        return_source_documents=True,
        chain_type_kwargs={"prompt": POLICY_CHAT_PROMPT},
    )

def _slugify(text: str) -> str:
    return re.sub(r'[^a-zA-Z0-9]+', '-', (text or '').strip()).strip('-').lower() or "file"

def _write_md_preview(title: str, body: str, meta: dict) -> str:
    """
    Writes a short markdown preview of the snippet to Cloud Storage and
    returns a public URL to the uploaded file.
    """
    if not GCP_BUCKET_PUBLIC:
        # Fallback: return empty link, or raise an error if you prefer
        return ""

    safe_title = title.replace(" ", "-").replace("/", "-")[:80]
    fname = f"{safe_title}.md"
    md_lines = [
        f"# {title}",
        "",
        body,
        "",
        f"---",
        f"**Source**: {meta.get('source','')}",
        f"**Page**: {meta.get('page','')}",
    ]
    md_text = "\n".join(md_lines)
    # store under md/ to keep things organized
    return upload_text(GCP_BUCKET_PUBLIC, f"md/{fname}", md_text, "text/markdown")

def _file_to_docs(path: Path) -> list:
    ext = path.suffix.lower()
    texts = []
    base_meta = {
        "source": str(path),
        "filename": path.name,
        "modified": datetime.utcfromtimestamp(path.stat().st_mtime).isoformat(),
    }
    if ext == ".pdf":
        from pypdf import PdfReader
        pdf = PdfReader(str(path))
        for i, page in enumerate(pdf.pages, start=1):
            text = page.extract_text()
            if text:
                texts.append({"page_content": text.strip(), "metadata": {**base_meta, "page": i}})
    elif ext == ".docx":
        import docx2txt
        content = docx2txt.process(str(path))
        if content:
            texts.append({"page_content": content.strip(), "metadata": {**base_meta}})
    elif ext in (".xlsx", ".xls"):
        df = pd.read_excel(str(path))
        texts.append({"page_content": df.to_csv(index=False), "metadata": {**base_meta}})
    elif ext == ".csv":
        df = pd.read_csv(str(path))
        texts.append({"page_content": df.to_csv(index=False), "metadata": {**base_meta}})
    elif ext in (".txt", ".md"):
        content = path.read_text(encoding="utf-8", errors="ignore").strip()
        if content:
            texts.append({"page_content": content, "metadata": {**base_meta}})

    docs = []
    for t in texts:
        chunks = SPLITTER.split_text(t["page_content"])
        for idx, c in enumerate(chunks):
            docs.append({"page_content": c, "metadata": {**t["metadata"], "chunk": idx}})
    return docs

def _load_vectorstore():
    _ensure_dirs()
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise ValueError("OPENAI_API_KEY missing in environment (.env).")
    embeddings = OpenAIEmbeddings(api_key=api_key)
    if INDEX_DIR.exists() and (INDEX_DIR / "index.faiss").exists():
        return FAISS.load_local(str(INDEX_DIR), embeddings, allow_dangerous_deserialization=True)
    if VSTORE_PKL.exists():
        with open(VSTORE_PKL, "rb") as f:
            return pickle.load(f)
    return None

def reindex_all() -> int:
    _ensure_dirs()
    all_docs = []
    for p in DOCS_DIR.rglob("*"):
        if p.is_file():
            all_docs.extend(_file_to_docs(p))
    if not all_docs:
        vs = FAISS.from_texts([" "], OpenAIEmbeddings(), metadatas=[{"notice": "empty"}])
    else:
        vs = FAISS.from_texts(
            [d["page_content"] for d in all_docs],
            OpenAIEmbeddings(),
            metadatas=[d["metadata"] for d in all_docs],
        )
    vs.save_local(str(INDEX_DIR))
    return len(all_docs)

def add_uploaded_file(filename: str, content: bytes) -> int:
    _ensure_dirs()
    out_path = DOCS_DIR / filename
    with open(out_path, "wb") as f:
        f.write(content)
    docs = _file_to_docs(out_path)
    vs = _load_vectorstore()
    if vs is None:
        return reindex_all()
    if docs:
        vs.add_texts([d["page_content"] for d in docs], metadatas=[d["metadata"] for d in docs])
        vs.save_local(str(INDEX_DIR))
    return len(docs)

def _normalize_email(value: Optional[str]) -> Optional[str]:
    if value is None:
        return None
    v = str(value).strip().lower()
    return v or None

def fetch_data_from_csv(intent: str, email: Optional[str]) -> pd.DataFrame:
    """
    Load tables/<intent>.csv and filter by email (case-insensitive).
    CSV MUST include a column named 'email'.
    """
    # Hardcoded for your current setup
    email = "sarathompson@colmeneroio.onmicrosoft.com"

    csv_file = TABLES_DIR / f"{intent}.csv"
    if not csv_file.exists():
        return pd.DataFrame()

    df = pd.read_csv(csv_file)
    df.columns = [c.strip().lower() for c in df.columns]

    if "email" not in df.columns:
        return pd.DataFrame()

    email_norm = _normalize_email(email)
    if not email_norm:
        return pd.DataFrame()

    series = df["email"].astype(str).str.strip().str.lower()
    filtered = df[series == email_norm]
    return filtered

_ALLOWED = {"vacation", "wfh", "general_policy"}

def _keyword_fallback(msg: str) -> str:
    m = (msg or "").lower()
    if "vacation" in m or "leave" in m or "holiday" in m:
        return "vacation"
    if "wfh" in m or "work from home" in m or "remote" in m:
        return "wfh"
    return "general_policy"

def classify_intent(message: str) -> str:
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise ValueError("OPENAI_API_KEY missing in environment (.env).")
    system = (
        "You are an intent classifier for an HR assistant.\n"
        "Allowed intents: 'vacation', 'wfh', 'general_policy'.\n"
        "Return ONLY JSON: {\"intent\":\"one_of_allowed\"}. No extra text."
    )
    human = f"Classify this user message:\n\n{message}"

    llm = ChatOpenAI(temperature=0)
    try:
        ai = llm.invoke([SystemMessage(content=system), HumanMessage(content=human)])
        raw = (ai.content or "").strip()
        start, end = raw.find("{"), raw.rfind("}")
        if start != -1 and end != -1:
            obj = json.loads(raw[start:end+1])
            intent = str(obj.get("intent", "")).strip().lower()
            if intent in _ALLOWED:
                return intent
    except Exception:
        pass
    return _keyword_fallback(message)

# ---------------- Citation builders (chunk-precise) ----------------
def _build_citations(source_docs: List[Any], limit: int = 3) -> List[Dict[str, Any]]:
    """
    Build precise citations from retrieved chunks. Each citation:
    - title: "<filename> (p.X, chunk Y)" when available
    - url: public MD preview link for that exact chunk
    - page, chunk, source, filename included for auditing
    """
    citations: List[Dict[str, Any]] = []
    seen = set()
    for doc in (source_docs or [])[:limit]:
        meta = doc.metadata or {}
        filename = Path(meta.get("filename", "")).name or "document"
        page = meta.get("page")
        chunk = meta.get("chunk")
        title_bits = [filename]
        if isinstance(page, int):
            title_bits.append(f"p.{page}")
        if chunk is not None:
            title_bits.append(f"chunk {chunk}")
        title = " ".join(title_bits)

        # Make a short preview markdown so the link points at exactly this chunk
        snippet = (doc.page_content or "").strip()
        snippet = snippet[:1200]  # keep it reasonable
        url = _write_md_preview(title=filename, body=snippet, meta=meta)

        key = (filename.lower(), page, chunk, url)
        if key in seen:
            continue
        seen.add(key)
        citations.append({
            "title": title,
            "url": url,
            "page": page,
            "chunk": chunk,
            "source": meta.get("source"),
            "filename": filename,
        })
    return citations

def _build_sources_for_compat(source_docs: List[Any], limit: int = 3) -> List[Dict[str, Any]]:
    """
    Back-compat 'sources' (without URLs) if some layers still read 'sources'.
    """
    sources = []
    seen = set()
    for doc in (source_docs or [])[:limit]:
        meta = doc.metadata or {}
        filename = Path(meta.get("filename", "")).name
        page = meta.get("page")
        chunk = meta.get("chunk")
        src = meta.get("source")
        key = (filename, page, chunk, src)
        if key in seen:
            continue
        seen.add(key)
        sources.append({
            "filename": filename,
            "page": page,
            "chunk": chunk,
            "source": src,
        })
    return sources

# ---------------- Main query paths ----------------
def query_policies(question: str, email: Optional[str] = None, k: int = 4) -> dict:
    # Small talk → short friendly reply, no references
    is_small, small_reply = classify_small_talk(question)
    if is_small:
        return {"intent": "general_policy", "answer": small_reply or "Hi! How can I help with HR today?", "references": [], "citations": []}

    intent = classify_intent(question)

    if intent in ("vacation", "wfh"):
        df = fetch_data_from_csv(intent, email)
        if df.empty:
            path_hint = TABLES_DIR / f"{intent}.csv"
            missing_reason = []
            if not path_hint.exists():
                missing_reason.append("table missing")
            if not email:
                missing_reason.append("email not provided")
            try:
                if path_hint.exists() and "email" not in [c.strip().lower() for c in pd.read_csv(path_hint).columns]:
                    missing_reason.append("CSV has no 'email' column")
            except Exception:
                pass
        # Return table preview (no external refs)
            return {
                "intent": intent,
                "answer": f"No matching record found for this email in '{intent}' table" + (f" ({', '.join(missing_reason)})" if missing_reason else "") + ".",
                "references": [{"title": f"tables/{intent}.csv"}],
                "citations": []
            }

        preview_rows = min(5, len(df))
        return {
            "intent": intent,
            "answer": df.head(preview_rows).to_string(index=False),
            "references": [{"title": f"tables/{intent}.csv", "rows_returned": preview_rows}],
            "citations": []
        }

    # general_policy → strict RAG
    vs = _load_vectorstore()
    if vs is None:
        reindex_all()
        vs = _load_vectorstore()
    retriever = vs.as_retriever(search_kwargs={"k": k})
    chain = _build_policy_chain(retriever)
    result = chain.invoke({"query": question})

    source_docs = result.get("source_documents", [])
    citations = _build_citations(source_docs, limit=3)
    sources = _build_sources_for_compat(source_docs, limit=3)

    return {
        "intent": "general_policy",
        "answer": (result.get("result") or "").strip(),
        "references": sources,     # back-compat field
        "citations": citations,    # precise doc+chunk (with public preview links)
    }

def answer_policy_only(question: str, k: int = 4) -> dict:
    """
    Strict policy-only RAG (no CSV, no intent classification).
    Returns both 'citations' (with URLs) and 'sources' (back-compat).
    """
    vs = _load_vectorstore()
    if vs is None:
        reindex_all()
        vs = _load_vectorstore()

    retriever = vs.as_retriever(search_kwargs={"k": k})
    llm = ChatOpenAI(temperature=0)
    chain = RetrievalQA.from_chain_type(
        llm=llm,
        retriever=retriever,
        chain_type="stuff",
        return_source_documents=True,
        chain_type_kwargs={"prompt": POLICY_CHAT_PROMPT},
    )
    result = chain.invoke({"query": question})

    source_docs = result.get("source_documents", [])
    citations = _build_citations(source_docs, limit=3)
    sources = _build_sources_for_compat(source_docs, limit=3)

    return {
        "answer": (result.get("result") or "").strip(),
        "citations": citations,    # preferred by orchestrator for precise refs
        "sources": sources         # back-compat
    }
