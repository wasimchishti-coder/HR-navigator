# services/query_orchestrator.py
import json
from typing import Optional, Dict, Any, List

from services.tabular_query_service import answer_tabular
from services.rag_policy_service import answer_policy_only
# from services.freshdesk_service import fetch_user_tickets, summarize_tickets_for_chat
from services.conversation_memory import get_history, add_message

from langchain_openai import ChatOpenAI
from langchain.schema import SystemMessage, HumanMessage, AIMessage

# IMPORTANT: public base for clickable links
PUBLIC_BASE_URL = "https://7ecddcde07bf.ngrok-free.app/api/messages"

# ---------------- LLM System Prompt ----------------
_COMBINE_SYS = """
You are a Human Resources (HR) assistant for a company.

Respond with:
- a friendly, professional, and concise tone
- human-like phrasing (do NOT mention AI)
- short, clear sentences; use bullets when listing multiple points
- answers that flow naturally with the conversation (use the last messages as context)
- no generic/static intros (avoid repeating who you are each time)
- policy references only when relevant and accurate
- clear acknowledgment if information is unavailable

Prioritize personal HR data (from tabular sources) over policy text when answering
questions specific to the employee (e.g., leave balance, payroll, WFH usage).
If it’s a policy question, answer based on the policy context.
If tickets are relevant, briefly summarize ticket status.

At the end (only when not small talk), include a compact "References" list in markdown
with clickable links (e.g., "- [WFH Policy](https://…/public/md/policy.md)").
"""

def _is_small_talk(text: str) -> bool:
    if not text:
        return False
    t = text.strip().lower()
    small = {"hi", "hello", "hey", "how are you", "thanks", "thank you", "who are you?"}
    return any(phrase in t for phrase in small)

def _combine_with_llm(
    query: str,
    tabular: Dict[str, Any],
    policy: Dict[str, Any],
    ticket: Optional[Dict[str, Any]],
    user_history: List[dict],
) -> str:
    llm = ChatOpenAI(temperature=0.3)

    msgs: List[Any] = [SystemMessage(content=_COMBINE_SYS)]

    # Feed last 12 messages as conversational context (user + assistant)
    for m in user_history[-12:]:
        role = (m.get("role") or "").lower()
        content = (m.get("content") or "").strip()
        if not content:
            continue
        if role == "user":
            msgs.append(HumanMessage(content=content))
        else:
            msgs.append(AIMessage(content=content))

    # Current query payload (HR data + policy + tickets)
    payload = {
        "query": query,
        "tabular": tabular or {},
        "policy": policy or {},
        "ticket": ticket or {},
    }
    msgs.append(HumanMessage(content=json.dumps(payload, ensure_ascii=False, indent=2)))

    out = llm.invoke(msgs).content or ""
    return out.strip()

def _tabular_across_known_tables(question: str, email: Optional[str]) -> Dict[str, Any]:
    """
    Try employee_records and transactional_hr_data. Return best non-empty result.
    """
    stems = ["employee_records", "transactional_hr_data"]
    for stem in stems:
        res = answer_tabular(question=question, user_email=email, dataset_hint=stem, allow_all_tables=False)
        # Accept if table existed and something meaningful returned (not N/A)
        ans = (res or {}).get("answer")
        if res and res.get("handled") and ans and str(ans).strip().upper() != "N/A":
            return res
    # Fallback when neither table produced a specific answer
    return {"handled": False, "answer": "", "natural": "", "source": None}

def _collect_references(policy_res: Dict[str, Any], tabular_res: Dict[str, Any], is_small: bool) -> List[Dict[str, str]]:
    """
    Create a unique list of clickable references. Skip for small talk.
    """
    if is_small:
        return []

    refs: List[Dict[str, str]] = []
    seen = set()

    # Policy sources (must include 'url' already)
    for s in (policy_res.get("sources") or []):
        url = (s.get("url") or "").strip()
        title = (s.get("title") or s.get("filename") or "reference").strip()
        if not url:
            continue
        key = (title.lower(), url)
        if key in seen:
            continue
        seen.add(key)
        refs.append({"title": title, "url": url})

    # Tabular source (e.g., "tables/employee_records.csv")
    t_src = (tabular_res.get("source") or "").strip()
    if t_src:
        # If not absolute, prefix with PUBLIC_BASE_URL
        if not (t_src.startswith("http://") or t_src.startswith("https://")):
            t_url = f"{PUBLIC_BASE_URL.rstrip('/')}/{t_src.lstrip('/')}"
        else:
            t_url = t_src
        key = (t_src.lower(), t_url)
        if key not in seen:
            seen.add(key)
            refs.append({"title": t_src.split("/")[-1], "url": t_url})

    return refs

def answer_query(
    message: str,
    email: Optional[str] = None,
    mode: Optional[str] = None,
    activity: Optional[dict] = None,
) -> Dict[str, Any]:
    """
    Unified HR query handler
    - Personal data (tabular): employee_records.csv / transactional_hr_data.csv
    - HR policy RAG
    - Freshdesk tickets
    - Conversation context (last 12 messages)
    - Clickable references
    - Logs all messages
    """
    user_id = (email or "_anon").strip().lower()
    history = get_history(user_id)

    # Personal (tabular) – try both known tables
    tabular_res = _tabular_across_known_tables(message, email)

    # Policy (RAG)
    policy_res = answer_policy_only(message, k=4)  # returns {"answer": str, "sources": [ {title, url, page?} ]}

    # Tickets (only if asked)
    ticket_res = None
    lower_msg = (message or "").lower()
    if "ticket" in lower_msg or "case" in lower_msg or "freshdesk" in lower_msg:
        tickets = fetch_user_tickets(email)
        ticket_res = {"summary": summarize_tickets_for_chat(tickets)}

    # Generate response w/ context
    reply = _combine_with_llm(
        query=message,
        tabular=tabular_res,
        policy=policy_res,
        ticket=ticket_res,
        user_history=history,
    )

    # Build references (skip for small talk)
    is_small = _is_small_talk(message)
    references = _collect_references(policy_res, tabular_res, is_small)

    # Log both sides
    add_message(user_id, "user", message)
    add_message(user_id, "assistant", reply)

    return {
        "answer": reply,
        "natural": reply,
        "intent": "combined",
        "references": references,
        "history": get_history(user_id),
    }


