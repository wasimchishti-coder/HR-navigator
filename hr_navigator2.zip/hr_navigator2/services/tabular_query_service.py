from __future__ import annotations
from typing import Optional, Dict, Any, List
import os
import json
import math
from pathlib import Path

import pandas as pd
from langchain_openai import ChatOpenAI
from langchain.schema import SystemMessage, HumanMessage

BASE_DIR = Path(__file__).resolve().parent.parent
TABLES_DIR = BASE_DIR / "data" / "tables"

# ------------------------------ IO helpers ------------------------------

def _load_table(stem: str) -> Optional[pd.DataFrame]:
    p = (TABLES_DIR / f"{stem}.csv")
    if not p.exists():
        return None
    df = pd.read_csv(p)
    # normalize to lowercase for robust matching
    df.columns = [c.strip().lower() for c in df.columns]
    return df

def _first_non_null(df: pd.DataFrame, col: str):
    s = df[col]
    for v in s:
        if pd.notna(v):
            return v
    return None

def _schema_with_samples(df: pd.DataFrame) -> Dict[str, Any]:
    """Return {columns: [..], samples: {col: first_non_null_value}} to guide the LLM."""
    samples = {}
    for c in df.columns:
        samples[c] = _first_non_null(df, c)
    return {"columns": list(df.columns), "samples": samples}

# ------------------------------ LLM Planner ------------------------------

_PLAN_INSTRUCTIONS = """You are a data analyst creating a PLAN to answer a user's question using ONLY the single dataset provided.
Return STRICT JSON with this schema (no prose, no markdown):

{
  "filters": [{"column": "<col>", "op": "=", "value": "<literal or {{user_email}}>"}],
  "select": ["<col1>", "<col2>"],
  "aggregation": {"op": "none|avg|sum|min|max|count", "column": "<col_or_empty_if_none>"},
  "result_type": "scalar|table|not_applicable",
  "reason": "<very brief reason>"
}

Rules:
- Use ONLY the dataset and columns from the list provided.
- If the question is PERSONAL (mentions 'my'/'me'/'I') and the dataset has an 'email' column, include a filter { "column":"email","op":"=","value":"{{user_email}}" }.
- Prefer "result_type":"scalar" when the user asks for a single number/value.
- If the user asks about a column's value for the current user, put that column in "select".
- If the question requires an aggregation (average, sum, min, max, count), set "aggregation" and include any filters.
- If the question is NOT about this dataset, return "result_type":"not_applicable".
- Never make up columns. Match the closest real column name from the list exactly.
- Keep filters simple: "=", "!=", ">", ">=", "<", "<=", or "contains".
Return only the JSON object.
"""

def _llm() -> ChatOpenAI:
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise ValueError("OPENAI_API_KEY is missing in environment (.env)")
    model = os.getenv("OPENAI_MODEL")
    return ChatOpenAI(temperature=0, model=model) if model else ChatOpenAI(temperature=0)

def _make_plan_for_table(question: str, df: pd.DataFrame, user_email: Optional[str]) -> Dict[str, Any]:
    schema = _schema_with_samples(df)
    sys = SystemMessage(content=_PLAN_INSTRUCTIONS + "\n\nDATASET COLUMNS & SAMPLES:\n" + json.dumps(schema, ensure_ascii=False, indent=2))
    usr = HumanMessage(content=f"User email (if needed): {user_email or ''}\n\nQuestion: {question}")
    msg = _llm().invoke([sys, usr]).content or ""
    s, e = msg.find("{"), msg.rfind("}")
    if s != -1 and e != -1:
        try:
            obj = json.loads(msg[s:e+1])
            # normalize shapes
            obj.setdefault("filters", [])
            obj.setdefault("select", [])
            obj.setdefault("aggregation", {"op": "none", "column": ""})
            obj.setdefault("result_type", "table")
            return obj
        except Exception:
            pass
    # fallback: not applicable
    return {
        "filters": [],
        "select": [],
        "aggregation": {"op": "none", "column": ""}, 
        "result_type": "not_applicable", 
        "reason": "parse_error",
    }

# ------------------------------ Execution ------------------------------

_ALLOWED_OPS = {"=", "!=", ">", ">=", "<", "<=", "contains"}
_ALLOWED_AGGS = {"none", "avg", "sum", "min", "max", "count"}

def _apply_filters(df: pd.DataFrame, filters: List[Dict[str, Any]], user_email: Optional[str]) -> pd.DataFrame:
    if not filters:
        return df
    res = df.copy()
    for f in filters:
        col = str(f.get("column", "")).strip().lower()
        op  = str(f.get("op", "=")).strip().lower()
        val = f.get("value", None)

        if col not in res.columns or op not in _ALLOWED_OPS:
            # ignore invalid filters
            continue

        # Inject email if requested
        if isinstance(val, str) and val.strip() == "{{user_email}}":
            val = (user_email or "").strip()

        series = res[col]
        if op == "=":
            res = res[series.astype(str).str.strip().str.lower() == str(val).strip().lower()]
        elif op == "!=":
            res = res[series.astype(str).str.strip().str.lower() != str(val).strip().lower()]
        elif op == "contains":
            res = res[series.astype(str).str.contains(str(val), case=False, na=False)]
        else:
            # numeric comparisons
            try:
                s = pd.to_numeric(series, errors="coerce")
                v = pd.to_numeric(pd.Series([val]), errors="coerce").iloc[0]
                if math.isnan(v):
                    continue
                if op == ">":
                    res = res[s > v]
                elif op == ">=":
                    res = res[s >= v]
                elif op == "<":
                    res = res[s < v]
                elif op == "<=":
                    res = res[s <= v]
            except Exception:
                pass
    return res

def _format_number(x) -> str:
    if pd.isna(x):
        return "N/A"
    try:
        xf = float(x)
        return str(int(xf)) if xf.is_integer() else f"{xf:.2f}"
    except Exception:
        return str(x)

def _execute_plan_for_df(plan: Dict[str, Any], df: pd.DataFrame, user_email: Optional[str], dataset_stem: str) -> Dict[str, Any]:
    # If dataset has email and it's a personal question but no email filter was added, auto-add it.
    if "email" in df.columns:
        has_email_filter = any(str(f.get("column","")).strip().lower() == "email" for f in plan.get("filters", []))
        if not has_email_filter and (user_email or "").strip():
            plan.setdefault("filters", []).append({"column":"email","op":"=","value":"{{user_email}}"})

    # Apply filters
    filtered = _apply_filters(df, plan.get("filters", []), user_email)

    # Normalize select/agg
    select = [c for c in (plan.get("select") or []) if c in filtered.columns]
    agg = plan.get("aggregation") or {}
    op = (agg.get("op") or "none").lower()
    col = (agg.get("column") or "").strip().lower()
    if op not in _ALLOWED_AGGS:
        op = "none"

    # Aggregation
    if op != "none":
        target_col = col if col in filtered.columns else (select[0] if select else None)
        if not target_col:
            return {
                "handled": True,
                "answer": "N/A",
                "natural": "No valid column for aggregation.",
                "source": f"tables/{dataset_stem}.csv",
            }
        ser = pd.to_numeric(filtered[target_col], errors="coerce")
        if op == "avg":
            val = ser.mean()
        elif op == "sum":
            val = ser.sum()
        elif op == "min":
            val = ser.min()
        elif op == "max":
            val = ser.max()
        elif op == "count":
            val = ser.count()
        return {
            "handled": True,
            "answer": _format_number(val),
            "natural": f"{op} of {target_col}: {_format_number(val)}",
            "source": f"tables/{dataset_stem}.csv",
        }

    # Scalar (one row, one col)
    if select:
        if len(filtered) == 1 and len(select) == 1:
            cell = filtered.iloc[0][select[0]]
            return {
                "handled": True,
                "answer": _format_number(cell),
                "natural": f"{select[0]}: {cell}",
                "source": f"tables/{dataset_stem}.csv",
            }
        # Otherwise a concise preview of selected columns
        out = filtered[select].head(10)
        return {
            "handled": True,
            "answer": out.to_string(index=False),
            "natural": "Filtered table preview.",
            "source": f"tables/{dataset_stem}.csv",
        }

    # If no select was specified: try to be helpful for a personal row
    if "email" in filtered.columns and len(filtered) == 1:
        row = filtered.iloc[0]
        # Show 6 most informative columns (non-empty, excluding email)
        cols = [c for c in filtered.columns if c != "email" and pd.notna(row[c])][:6]
        if not cols:
            cols = [c for c in filtered.columns if c != "email"][:6]
        summary = row[cols].to_string()
        return {
            "handled": True,
            "answer": summary,
            "natural": "Your record (summary).",
            "source": f"tables/{dataset_stem}.csv",
        }

    # Nothing matched
    if filtered.empty:
        return {"handled": True, "answer": "N/A", "natural": "No matching rows.", "source": f"tables/{dataset_stem}.csv"}

    # Default: small overall preview
    return {
        "handled": True,
        "answer": filtered.head(10).to_string(index=False),
        "natural": "Table preview.",
        "source": f"tables/{dataset_stem}.csv",
    }

# ------------------------------ Public API ------------------------------

from typing import Optional, Dict, Any

def answer_tabular(
    question: str,
    user_email: Optional[str],
    dataset_hint: Optional[str] = None,   # <-- add default
    allow_all_tables: bool = False,       # <-- keep default
) -> Dict[str, Any]:
    """
    Answer using ONLY the tab selected by the user (dataset_hint).
    The LLM planner is restricted to that table's columns, so the user can ask
    about ANY column (e.g., carryover, accrual_rate, used_days, etc.).
    Returns: {"handled": bool, "answer": str, "natural": str, "source": "tables/<file>.csv"}
    """
    if not dataset_hint and not allow_all_tables:
        return {"handled": False, "answer": None, "natural": None, "source": None}

    stem = (dataset_hint or "").strip().lower()
    df = _load_table(stem)
    if df is None:
        return {"handled": True, "answer": "N/A", "natural": f"Table '{stem}.csv' not found.", "source": f"tables/{stem}.csv"}

    # If the table is personal and caller didn't provide email, stop early.
    if "email" in df.columns and not (user_email or "").strip():
        return {"handled": True, "answer": "N/A", "natural": "Email is required for this tab.", "source": f"tables/{stem}.csv"}

    # Make a plan confined to THIS table, then execute.
    plan = _make_plan_for_table(question, df, user_email)
    if (plan.get("result_type") or "") == "not_applicable":
        return {"handled": False, "answer": None, "natural": None, "source": None}

    return _execute_plan_for_df(plan, df, user_email, stem)
import pandas as pd
from pathlib import Path

def fetch_sara_data_from_csv() -> pd.DataFrame:
    # Assuming email for Sara Thompson is "sarathompson@company.com"
    email = "sarathompson@company.com"
    
    # Path to your transactional HR data file
    csv_file = Path("data") / "tables" / "transactional_hr_data.csv"
    
    if not csv_file.exists():
        return pd.DataFrame()  # Return empty DataFrame if file is not found
    
    df = pd.read_csv(csv_file)
    df.columns = [col.strip().lower() for col in df.columns]  # Normalize columns to lowercase
    
    # Filter data by email (case-insensitive)
    email_norm = email.lower()
    filtered_data = df[df["email"].str.strip().str.lower() == email_norm]
    
    return filtered_data
