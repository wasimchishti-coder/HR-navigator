# services/teams_identity.py
import requests
from typing import Optional
from config import MICROSOFT_APP_ID, MICROSOFT_APP_PASSWORD

_TOKEN_URL = "https://login.microsoftonline.com/botframework.com/oauth2/v2.0/token"

def _get_app_token() -> str:
    data = {
        "grant_type": "client_credentials",
        "client_id": MICROSOFT_APP_ID,
        "client_secret": MICROSOFT_APP_PASSWORD,
        "scope": "https://api.botframework.com/.default",
    }
    r = requests.post(_TOKEN_URL, data=data, timeout=10)
    r.raise_for_status()
    return r.json()["access_token"]

def get_teams_user_email(service_url: str, conversation_id: str, user_id: str) -> Optional[str]:
    """
    Calls Bot Framework connector to resolve the Teams member profile.
    Returns 'email' or 'userPrincipalName' (lowercased) if available.
    """
    token = _get_app_token()
    # NOTE: serviceUrl in activity already has a trailing slash
    url = f"{service_url}v3/conversations/{conversation_id}/members/{user_id}"
    headers = {"Authorization": f"Bearer {token}"}
    r = requests.get(url, headers=headers, timeout=10)
    if not r.ok:
        return None
    m = r.json() if r.headers.get("Content-Type", "").startswith("application/json") else {}
    email = (m.get("email") or m.get("userPrincipalName") or "").strip().lower()
    return email or None
