import re
from sentence_transformers import SentenceTransformer, util

# Load embedding model once
_model = SentenceTransformer("all-MiniLM-L6-v2")

# Dataset descriptions
DATASETS = {
    "leave_balance": "Information about remaining annual and sick leave days for employees.",
    "work_from_home": "Records of employee work from home requests and approvals.",
    "ticket_status": "Support ticket requests and their current status.",
    "payroll": "Payroll, salary slips, and compensation details for employees.",
    "general_hr_policy": "General HR policies and procedures for employees."
}

_dataset_embeddings = {k: _model.encode(v, convert_to_tensor=True) for k, v in DATASETS.items()}

def classify_intent(question: str, user_email: str = None) -> str:
    """
    Classifies the intent of a given question using sentence embeddings.
    Returns the most relevant dataset key or general HR policy intent.
    """
    q_emb = _model.encode(question, convert_to_tensor=True)
    scores = {k: util.pytorch_cos_sim(q_emb, emb).item() for k, emb in _dataset_embeddings.items()}
    best, score = max(scores.items(), key=lambda x: x[1])

    # If the score is too low, classify it as a general HR policy query
    if score < 0.4:
        return "general_hr_policy"
    
    # Check if the question is related to transactional data or employee records
    if best in ["leave_balance", "work_from_home", "payroll"]:
        if user_email == "sarathompson@colmeneroio.onmicrosoft.com":
            return best  # Return only if email matches
        return "general_hr_policy"  # Otherwise, general HR policy
    
    # Return the best match
    return best

def detect_intent(message: str, user_email: str = None) -> str:
    """
    Detects intent and returns one of: 'general_hr_policy', 'transactional_data', 'employee_records', 'ticket_status'
    """
    text = (message or "").strip().lower()

    # Classifying based on specific keywords for transactional data or employee records
    if any(k in text for k in ["vacation", "leave", "holiday", "pto", "work from home", "wfh", "remote"]):
        return "transactional_data" if user_email == "sarathompson@colmeneroio.onmicrosoft.com" else "general_hr_policy"
    
    if "ticket" in text or re.search(r"#\d{2,}", text):
        return "ticket_status"

    # Fallback to general HR policy if no match
    return "general_hr_policy"
