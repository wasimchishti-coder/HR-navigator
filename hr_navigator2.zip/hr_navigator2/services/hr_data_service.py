import json

def load_hr_data():
    with open("data/hr_users.json") as f:
        return json.load(f)

def get_user_profile(email):
    users = load_hr_data()
    return users.get(email, {})

def get_vacation_days(profile):
    return profile.get("remaining_holidays", "N/A")

# hr_data_service.py

# from services import policies  # if you already have models imported


def query_leave_balance(question: str, user_email: str):
    # Example stub → replace with your SQL/ORM
    return {
        "answer": "You have 12 leave days remaining.",
        "natural": f"According to your records, you have 12 annual leave days remaining.",
    }

def query_work_from_home(question: str, user_email: str):
    return {
        "answer": "You used 5 WFH days this month.",
        "natural": f"You have already used 5 work-from-home days this month.",
    }

def query_ticket_status(question: str, user_email: str):
    return {
        "answer": "Your last ticket is still open.",
        "natural": "Your latest support ticket is still being processed.",
    }

def query_payroll(question: str, user_email: str):
    return {
        "answer": "Your July salary was processed.",
        "natural": "Your payroll records show that your July salary has been processed.",
    }

# Central dispatcher
def run_query(dataset: str, question: str, user_email: str = None) -> dict | None:
    """
    Dispatch queries to the correct HR dataset.
    Returns dict with {answer, natural}, or None if no handler.
    """
    dataset_map = {
        "leave_balance": query_leave_balance,
        "work_from_home": query_work_from_home,
        "ticket_status": query_ticket_status,
        "payroll": query_payroll,
    }

    handler = dataset_map.get(dataset)
    if not handler:
        return None
    return handler(question, user_email)
